@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo [안내] Node.js가 설치되어 있지 않아 단일 실행 HTML 버전을 바로 엽니다.
  start "" "%~dp0AI_착수계자동작성_단일실행본.html"
  exit /b 0
)
echo [AI_착수계자동작성] 로컬 서버(http://127.0.0.1:4175/)를 시작합니다...
start "" "http://127.0.0.1:4175/"
node "%~dp0app\server.js"
