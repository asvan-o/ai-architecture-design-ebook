@echo off
chcp 65001 >nul
for /f "tokens=5" %%a in ('netstat -aon ^| findstr "127.0.0.1:4175" ^| findstr "LISTENING"') do (
  echo [AI_착수계자동작성] 포트 4175 프로세스(PID %%a)를 종료합니다.
  taskkill /F /PID %%a >nul 2>nul
)
echo 종료 확인 완료.
