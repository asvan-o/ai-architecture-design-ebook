// 건축 용역 행정서류 4종(착수신고서·책임기술자 선임계·참여기술자 명단·보안각서) HTML 조립기
function esc(v) {
  return String(v ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function placeholderOrValue(v, label) {
  const s = String(v ?? '').trim();
  return s ? esc(s) : `<span class="doc-missing">[사람 확인 필요: ${esc(label)}]</span>`;
}

function renderFourDocuments(input, summary, validation) {
  const isAmendment = input.filingType === '변경착수계';
  const doc1Title = isAmendment ? '용 역 변 경 착 수 신 고 서' : '용 역 착 수 신 고 서';
  const engineers = Array.isArray(input.engineers) ? input.engineers : [];

  const warningBanner = validation.passed
    ? ''
    : `<div class="doc-draft-banner">검수 대기 초안 · 누락 또는 모순 항목 ${validation.issueCount}건을 사람이 확인한 뒤 직인 날인·제출하세요.</div>`;

  const amendmentRows = isAmendment
    ? `<tr><th>당초 계약 기준</th><td colspan="3">${placeholderOrValue(input.previousSummary, '당초 금액·준공일 기재')}</td></tr>
       <tr><th>변경 사유</th><td colspan="3">${placeholderOrValue(input.changeReason, '변경 사유 기재')}</td></tr>`
    : '';

  const sheet1 = `
  <section class="doc-sheet" data-doc-sheet="commencement">
    ${warningBanner}
    <p class="doc-form-code">[서식 1 · ${isAmendment ? '변경착수계' : '신규착수계'}]</p>
    <h2 class="doc-title">${doc1Title}</h2>
    <table class="doc-table">
      <tbody>
        <tr><th>1. 용 역 명</th><td colspan="3"><strong>${placeholderOrValue(input.projectName, '용역명')}</strong></td></tr>
        <tr><th>2. 발 주 기 관</th><td>${placeholderOrValue(input.clientName, '발주처')}</td><th>계약번호/방식</th><td>${esc(input.contractNo || '수의/일반용역')}</td></tr>
        <tr><th>3. 계 약 금 액</th><td colspan="3"><strong>${esc(summary.koreanLegalAmount)} (${esc(summary.totalFormatted)})</strong><br/><small>공급가액: ${esc(summary.supplyFormatted)} / 부가가치세: ${esc(summary.vatFormatted)} (${esc(summary.vatMode)})</small></td></tr>
        <tr><th>4. 계 약 일 자</th><td>${placeholderOrValue(input.contractDate, '계약일')}</td><th>5. 착 수 일 자</th><td>${placeholderOrValue(input.startDate, '착수일')}</td></tr>
        <tr><th>6. 준공예정일</th><td>${placeholderOrValue(input.endDate, '준공예정일')}</td><th>7. 과 업 기 간</th><td><strong>${esc(summary.durationLabel)}</strong></td></tr>
        ${amendmentRows}
        <tr><th>8. 현장/대지위치</th><td colspan="3">${esc(input.siteLocation || '과업지시서 기준 대지')}</td></tr>
      </tbody>
    </table>
    <p class="doc-statement">위 용역 계약에 대하여 ${isAmendment ? '변경 과업 조건에 따라 변경 착수신고서를' : '소정의 서류를 갖추어 착수신고서를'} 제출합니다.</p>
    <div class="doc-attachments">
      <strong>첨부서류</strong>
      <ol>
        <li>책임기술자(총괄건축사) 선임계 1부</li>
        <li>분야별 참여기술자 명단 1부</li>
        <li>보안각서 1부 (예정공정표·자격증 사본은 발주처 양식에 따라 별도 첨부)</li>
      </ol>
    </div>
    <p class="doc-date">${placeholderOrValue(input.submitDate, '제출일자')}</p>
    <div class="doc-sign-block">
      <p>상 호(사무소명) : ${placeholderOrValue(input.firmName, '건축사사무소명')} (개설신고번호: ${placeholderOrValue(input.firmRegNo, '개설신고번호')})</p>
      <p>소 재 지 : ${esc(input.firmAddress || '사무소 주소 입력')}</p>
      <p>대 표 자 : 대표 건축사 <strong>${placeholderOrValue(input.representative, '대표자명')}</strong> <span class="seal-box">(직인 확인)</span></p>
    </div>
    <p class="doc-recipient">${placeholderOrValue(input.clientName, '발주기관장')} 귀하</p>
  </section>`;

  const sheet2 = `
  <section class="doc-sheet" data-doc-sheet="appointment">
    ${warningBanner}
    <p class="doc-form-code">[서식 2 · 책임기술자 선임계]</p>
    <h2 class="doc-title">책 임 기 술 자 선 임 계</h2>
    <table class="doc-table">
      <tbody>
        <tr><th>용 역 명</th><td colspan="3">${placeholderOrValue(input.projectName, '용역명')}</td></tr>
        <tr><th>성 명</th><td><strong>${placeholderOrValue(input.leadName, '책임기술자 성명')}</strong></td><th>직 위</th><td>${esc(input.leadTitle || '책임건축사(총괄)')}</td></tr>
        <tr><th>자격종목 및 번호</th><td>건축사 · ${placeholderOrValue(input.leadLicenseNo, '자격번호')}</td><th>연 락 처</th><td>${esc(input.leadPhone || '사무소 대표번호')}</td></tr>
        <tr><th>참 여 기 간</th><td colspan="3">${placeholderOrValue(input.startDate, '착수일')} ~ ${placeholderOrValue(input.endDate, '준공예정일')} (${esc(summary.durationLabel)})</td></tr>
        <tr><th>담당 업무 범위</th><td colspan="3">${esc(input.leadScope || '건축설계 총괄, 발주기관 협의, 도서 품질 및 법규 정합성 총괄 관리')}</td></tr>
      </tbody>
    </table>
    <p class="doc-statement">위 사람을 본 용역의 책임기술자(총괄건축사)로 선임하여 제출하오니 승인하여 주시기 바랍니다. 책임기술자가 수행한 일체의 설계·협의 행위는 당 사무소를 대리합니다.</p>
    <p class="doc-date">${placeholderOrValue(input.submitDate, '제출일자')}</p>
    <div class="doc-sign-block">
      <p>상 호 : ${placeholderOrValue(input.firmName, '건축사사무소명')}</p>
      <p>대 표 자 : ${placeholderOrValue(input.representative, '대표자명')} <span class="seal-box">(직인 확인)</span></p>
    </div>
    <p class="doc-recipient">${placeholderOrValue(input.clientName, '발주기관장')} 귀하</p>
  </section>`;

  const rosterRows = engineers.length > 0
    ? engineers.map((eng, i) => `<tr>
        <td>${i + 1}</td>
        <td>${placeholderOrValue(eng.field, '분야')}</td>
        <td><strong>${placeholderOrValue(eng.name, '성명')}</strong></td>
        <td>${esc(eng.position || '참여기술자')}</td>
        <td>${placeholderOrValue(eng.license, '자격번호')}</td>
        <td>${esc(eng.task || '분야별 설계·검토')}</td>
        <td class="sign-cell">(서명)</td>
      </tr>`).join('')
    : `<tr><td colspan="7"><span class="doc-missing">[사람 확인 필요: 참여기술자 최소 1명 이상 입력]</span></td></tr>`;

  const sheet3 = `
  <section class="doc-sheet" data-doc-sheet="roster">
    ${warningBanner}
    <p class="doc-form-code">[서식 3 · 참여기술자 명단]</p>
    <h2 class="doc-title">분 야 별 참 여 기 술 자 명 단</h2>
    <p class="doc-meta-line"><strong>용역명:</strong> ${placeholderOrValue(input.projectName, '용역명')} &nbsp;|&nbsp; <strong>과업기간:</strong> ${placeholderOrValue(input.startDate, '착수일')} ~ ${placeholderOrValue(input.endDate, '준공일')} (${esc(summary.durationLabel)})</p>
    <table class="doc-table doc-roster-table">
      <thead>
        <tr><th>연번</th><th>참여분야</th><th>성명</th><th>직위</th><th>자격종목·번호</th><th>담당업무</th><th>본인확인</th></tr>
      </thead>
      <tbody>${rosterRows}</tbody>
    </table>
    <p class="doc-date">${placeholderOrValue(input.submitDate, '제출일자')}</p>
    <div class="doc-sign-block">
      <p>제출자 : ${placeholderOrValue(input.firmName, '건축사사무소명')} 대표 ${placeholderOrValue(input.representative, '대표자명')} <span class="seal-box">(직인 확인)</span></p>
    </div>
    <p class="doc-recipient">${placeholderOrValue(input.clientName, '발주기관장')} 귀하</p>
  </section>`;

  const sheet4 = `
  <section class="doc-sheet" data-doc-sheet="security">
    ${warningBanner}
    <p class="doc-form-code">[서식 4 · 보안각서]</p>
    <h2 class="doc-title">보 안 각 서</h2>
    <table class="doc-table">
      <tbody>
        <tr><th>용 역 명</th><td>${placeholderOrValue(input.projectName, '용역명')}</td><th>과업기간</th><td>${placeholderOrValue(input.startDate, '착수일')} ~ ${placeholderOrValue(input.endDate, '준공일')}</td></tr>
      </tbody>
    </table>
    <ol class="doc-pledge">
      <li>당 사무소 및 참여기술자 전원은 위 용역을 수행함에 있어 발주기관으로부터 제공받은 도서·현황자료·내부 행정정보를 본 과업 목적 외에 사용하지 않겠습니다.</li>
      <li>과업 수행 중 생산되는 모든 도면·보고서·검토 자료를 발주기관의 사전 승인 없이 외부에 공개하거나 비인가 클라우드·외부 AI 학습 데이터로 무단 전송하지 않겠습니다.</li>
      <li>과업 종료 후에도 업무상 알게 된 보안사항을 누설하지 않으며, 위반 시 관계 법령 및 계약 조건에 따른 책임을 질 것을 서약합니다.</li>
    </ol>
    <p class="doc-date">${placeholderOrValue(input.submitDate, '제출일자')}</p>
    <div class="doc-sign-block">
      <p>서약 대표자 : ${placeholderOrValue(input.firmName, '건축사사무소명')} 대표 ${placeholderOrValue(input.representative, '대표자명')} <span class="seal-box">(직인 확인)</span></p>
      <p>책임기술자 : ${placeholderOrValue(input.leadName, '책임기술자 성명')} (서명)</p>
    </div>
    <p class="doc-recipient">${placeholderOrValue(input.clientName, '발주기관장')} 귀하</p>
  </section>`;

  return { sheet1, sheet2, sheet3, sheet4, combinedHtml: sheet1 + sheet2 + sheet3 + sheet4 };
}

function buildStandaloneExportDocument(input, summary, validation, forWord = false) {
  const { combinedHtml } = renderFourDocuments(input, summary, validation);
  const wordMeta = forWord
    ? '<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />'
    : '<meta charset="utf-8" />';
  return `<!doctype html>
<html lang="ko">
<head>
${wordMeta}
<title>${esc(input.projectName || '착수계_패키지')}_행정서류4종</title>
<style>
  @page { size: A4; margin: 16mm; }
  body { font-family: 'Malgun Gothic', 'Apple SD Gothic Neo', sans-serif; color: #111827; margin: 0; padding: 0; line-height: 1.55; }
  .doc-sheet { page-break-after: always; padding: 10mm 6mm; box-sizing: border-box; }
  .doc-sheet:last-child { page-break-after: auto; }
  .doc-form-code { font-size: 11px; color: #4b5563; margin: 0 0 6px; }
  .doc-title { text-align: center; font-size: 22px; letter-spacing: 3px; margin: 8px 0 18px; border-bottom: 2px solid #111827; padding-bottom: 10px; }
  .doc-table { width: 100%; border-collapse: collapse; margin-bottom: 16px; font-size: 13px; }
  .doc-table th, .doc-table td { border: 1px solid #374151; padding: 8px 10px; text-align: left; vertical-align: middle; }
  .doc-table th { background: #f3f4f6; width: 20%; font-weight: 700; }
  .doc-roster-table th { width: auto; text-align: center; }
  .doc-statement { margin: 18px 0; font-size: 14px; font-weight: 600; text-align: center; }
  .doc-attachments, .doc-pledge { font-size: 13px; margin: 14px 0; }
  .doc-date { text-align: center; font-size: 14px; font-weight: 700; margin: 22px 0 14px; }
  .doc-sign-block { margin-left: 28%; font-size: 13.5px; line-height: 1.8; }
  .seal-box { display: inline-block; border: 1px dashed #6b7280; padding: 1px 8px; font-size: 11px; color: #4b5563; margin-left: 6px; }
  .doc-recipient { text-align: right; font-size: 16px; font-weight: 800; margin-top: 22px; }
  .doc-missing { color: #b45309; font-weight: 700; background: #fef3c7; padding: 1px 4px; }
  .doc-draft-banner { border: 1.5px solid #b45309; background: #fffbeb; color: #92400e; padding: 8px 12px; font-size: 12px; font-weight: 700; margin-bottom: 10px; }
</style>
</head>
<body>${combinedHtml}</body>
</html>`;
}

if (typeof module !== 'undefined') {
  module.exports = { renderFourDocuments, buildStandaloneExportDocument };
}
