// 자동 조립 가능 여부와 사람 확인(검수 대기) 사유 판정기
const REQUIRED_FIELDS = [
  ['projectName', '용역명(과업명)이 비어 있습니다.'],
  ['clientName', '발주처(발주기관) 이름이 비어 있습니다.'],
  ['contractDate', '계약일자가 입력되지 않았습니다.'],
  ['startDate', '착수일자가 입력되지 않았습니다.'],
  ['endDate', '준공예정일이 입력되지 않았습니다.'],
  ['submitDate', '제출일자가 입력되지 않았습니다.'],
  ['firmName', '건축사사무소명이 비어 있습니다.'],
  ['firmRegNo', '건축사사무소 개설신고번호가 누락되었습니다(임의 생성 금지).'],
  ['representative', '대표 건축사 성명이 비어 있습니다.'],
  ['leadName', '책임기술자 성명이 비어 있습니다.'],
  ['leadLicenseNo', '책임기술자(건축사) 자격번호가 누락되었습니다(임의 생성 금지).'],
];

function validateCommencementInput(input, summary) {
  const issues = [];
  for (const [key, msg] of REQUIRED_FIELDS) {
    if (!String(input[key] ?? '').trim()) {
      issues.push({ code: 'MISSING_' + key.toUpperCase(), field: key, message: msg });
    }
  }

  if (!summary.rawAmount || summary.rawAmount <= 0) {
    issues.push({ code: 'INVALID_AMOUNT', field: 'contractAmount', message: '계약금액은 0보다 큰 숫자여야 합니다.' });
  }

  if (input.vatMode === '미확정') {
    issues.push({ code: 'UNSPECIFIED_VAT', field: 'vatMode', message: '부가세 포함/별도 구분이 미확정 상태입니다. 계약서 원문을 확인해 선택하세요.' });
  }

  if (summary.durationDays !== null && summary.durationDays <= 0) {
    issues.push({
      code: 'DATE_INVERSION',
      field: 'endDate',
      message: `준공예정일(${input.endDate})이 착수일자(${input.startDate})보다 빠릅니다. 날짜 역전을 확인하세요.`,
    });
  }

  if (input.contractDate && input.startDate && input.contractDate > input.startDate) {
    issues.push({
      code: 'CONTRACT_AFTER_START',
      field: 'contractDate',
      message: `계약일자(${input.contractDate})가 착수일자(${input.startDate})보다 늦습니다. 사전 착수 승인 여부를 사람이 확인하세요.`,
    });
  }

  if (input.filingType === '변경착수계') {
    if (!String(input.changeReason ?? '').trim()) {
      issues.push({
        code: 'MISSING_CHANGE_REASON',
        field: 'changeReason',
        message: '변경착수계 선택 시 변경 사유(계약금액 조정·과업기간 연장 등)를 반드시 입력해야 합니다.',
      });
    }
    if (!String(input.previousSummary ?? '').trim()) {
      issues.push({
        code: 'MISSING_PREVIOUS_SUMMARY',
        field: 'previousSummary',
        message: '변경착수계 선택 시 당초 계약 내용(당초 금액·당초 준공일)을 기재해야 비교 표기가 가능합니다.',
      });
    }
  }

  const engineers = Array.isArray(input.engineers) ? input.engineers : [];
  if (engineers.length === 0) {
    issues.push({ code: 'EMPTY_ROSTER', field: 'engineers', message: '참여기술자 명단에 최소 1명 이상 등록되어야 합니다.' });
  } else {
    engineers.forEach((eng, idx) => {
      if (!String(eng.name ?? '').trim() || !String(eng.field ?? '').trim() || !String(eng.license ?? '').trim()) {
        issues.push({
          code: 'INCOMPLETE_ENGINEER_' + (idx + 1),
          field: 'engineers',
          message: `참여기술자 ${idx + 1}번 행의 성명·분야·자격번호 중 빈칸이 있습니다.`,
        });
      }
    });
  }

  const status = issues.length === 0 ? '자동 조립 완료' : '사람 확인(검수 대기)';
  return {
    passed: issues.length === 0,
    status,
    issueCount: issues.length,
    issues,
  };
}

if (typeof module !== 'undefined') {
  module.exports = { validateCommencementInput };
}
