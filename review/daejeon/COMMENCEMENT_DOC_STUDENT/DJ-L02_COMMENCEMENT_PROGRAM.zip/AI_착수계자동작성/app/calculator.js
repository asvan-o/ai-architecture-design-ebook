// 계약금액 한글 표기(일금 ...원정), 부가세 공급가/세액 계산, 착수~준공 총 과업일수 산출
const DIGITS = ['', '일', '이', '삼', '사', '오', '육', '칠', '팔', '구'];
const SMALL_UNITS = ['', '십', '백', '천'];
const BIG_UNITS = ['', '만', '억', '조'];

function toKoreanNumber(num) {
  const n = Math.floor(Number(num) || 0);
  if (n <= 0) return '';
  const str = String(n);
  const groups = [];
  for (let i = str.length; i > 0; i -= 4) {
    groups.unshift(str.slice(Math.max(0, i - 4), i));
  }
  const parts = [];
  const totalGroups = groups.length;
  groups.forEach((group, idx) => {
    const val = Number(group);
    if (val === 0) return;
    let chunk = '';
    const padded = group.padStart(4, '0');
    for (let j = 0; j < 4; j++) {
      const d = Number(padded[j]);
      if (d === 0) continue;
      const unit = SMALL_UNITS[3 - j];
      // 천·백·십 자리에서도 행정·계약 금액 표기는 '일천·일백' 또는 표준 한글 수사 규칙 중
      // 오독 방지를 위해 만·억 앞의 1만 '일억', '일만'(단, 천/백/십은 표준 '삼천팔백오십')으로 표기
      const digitText = (d === 1 && unit !== '') ? '' : DIGITS[d];
      chunk += digitText + unit;
    }
    const bigUnit = BIG_UNITS[totalGroups - 1 - idx] || '';
    parts.push(chunk + bigUnit);
  });
  return parts.join('');
}

function formatWon(n) {
  return '₩' + Math.round(Number(n) || 0).toLocaleString('ko-KR');
}

function calculateContractSummary(input) {
  const rawAmount = Math.round(Number(String(input.contractAmount ?? '').replace(/[^0-9.-]/g, '')) || 0);
  const vatMode = input.vatMode || '부가세포함';
  let supplyAmount = 0;
  let vatAmount = 0;
  let totalAmount = rawAmount;

  if (rawAmount > 0) {
    if (vatMode === '부가세포함') {
      supplyAmount = Math.round(rawAmount / 1.1);
      vatAmount = rawAmount - supplyAmount;
      totalAmount = rawAmount;
    } else if (vatMode === '부가세별도') {
      supplyAmount = rawAmount;
      vatAmount = Math.round(rawAmount * 0.1);
      totalAmount = supplyAmount + vatAmount;
    } else {
      supplyAmount = rawAmount;
      vatAmount = 0;
      totalAmount = rawAmount;
    }
  }

  const koreanText = totalAmount > 0 ? `일금 ${toKoreanNumber(totalAmount)}원정` : '금액 미입력';

  let durationDays = null;
  if (input.startDate && input.endDate) {
    const s = new Date(input.startDate + 'T00:00:00Z');
    const e = new Date(input.endDate + 'T00:00:00Z');
    if (!Number.isNaN(s.getTime()) && !Number.isNaN(e.getTime())) {
      durationDays = Math.floor((e.getTime() - s.getTime()) / 86400000) + 1;
    }
  }

  return {
    rawAmount,
    vatMode,
    supplyAmount,
    vatAmount,
    totalAmount,
    supplyFormatted: formatWon(supplyAmount),
    vatFormatted: formatWon(vatAmount),
    totalFormatted: formatWon(totalAmount),
    koreanLegalAmount: koreanText,
    fullAmountLabel: totalAmount > 0 ? `${koreanText} (${formatWon(totalAmount)}, ${vatMode})` : '금액 미확정',
    durationDays,
    durationLabel: durationDays && durationDays > 0 ? `총 ${durationDays}일간` : '기간 확인 필요',
  };
}

if (typeof module !== 'undefined') {
  module.exports = { toKoreanNumber, formatWon, calculateContractSummary };
}
