(function () {
  const FIELDS = [
    'filingType', 'contractNo', 'projectName', 'clientName', 'siteLocation',
    'contractAmount', 'vatMode', 'contractDate', 'submitDate', 'startDate', 'endDate',
    'previousSummary', 'changeReason', 'firmName', 'firmRegNo', 'representative',
    'firmAddress', 'leadName', 'leadLicenseNo'
  ];

  const DEFAULT_SAMPLES = window.__EMBEDDED_SAMPLES__ || null;
  let engineers = [];
  let activeTab = 'all';

  const el = (id) => document.getElementById(id);

  function renderEngineerInputs() {
    const host = el('engineers-list');
    host.innerHTML = '';
    engineers.forEach((eng, idx) => {
      const row = document.createElement('div');
      row.className = 'eng-row';
      row.innerHTML = `
        <input type="text" placeholder="분야(건축/구조)" value="${(eng.field || '').replace(/"/g, '&quot;')}" data-eng-idx="${idx}" data-eng-key="field" aria-label="참여기술자 ${idx+1} 분야" />
        <input type="text" placeholder="성명" value="${(eng.name || '').replace(/"/g, '&quot;')}" data-eng-idx="${idx}" data-eng-key="name" aria-label="참여기술자 ${idx+1} 성명" />
        <input type="text" placeholder="자격번호" value="${(eng.license || '').replace(/"/g, '&quot;')}" data-eng-idx="${idx}" data-eng-key="license" aria-label="참여기술자 ${idx+1} 자격번호" />
        <input type="text" placeholder="담당업무" value="${(eng.task || '').replace(/"/g, '&quot;')}" data-eng-idx="${idx}" data-eng-key="task" aria-label="참여기술자 ${idx+1} 담당업무" />
        <button type="button" class="secondary" data-eng-remove="${idx}" aria-label="참여기술자 ${idx+1} 삭제">삭제</button>
      `;
      host.appendChild(row);
    });
  }

  function collectFormData() {
    const data = {};
    FIELDS.forEach((k) => { data[k] = el(k) ? el(k).value : ''; });
    data.contractAmount = Number(data.contractAmount || 0);
    data.engineers = engineers.map((e) => ({ ...e }));
    return data;
  }

  function applyFormData(data) {
    FIELDS.forEach((k) => {
      if (el(k)) el(k).value = data[k] !== undefined && data[k] !== null ? String(data[k]) : '';
    });
    engineers = Array.isArray(data.engineers) ? data.engineers.map((e) => ({ ...e })) : [];
    renderEngineerInputs();
    refreshPreview();
  }

  function applyTabFilter() {
    document.querySelectorAll('#doc-preview .doc-sheet').forEach((sheet) => {
      sheet.hidden = activeTab !== 'all' && sheet.getAttribute('data-doc-sheet') !== activeTab;
    });
  }

  function refreshPreview() {
    const data = collectFormData();
    el('amendment-fields').hidden = data.filingType !== '변경착수계';
    const summary = calculateContractSummary(data);
    const validation = validateCommencementInput(data, summary);
    const rendered = renderFourDocuments(data, summary, validation);

    el('live-calc-summary').innerHTML = `
      <strong>${summary.koreanLegalAmount} (${summary.totalFormatted})</strong>
      <span>공급가액 ${summary.supplyFormatted} · 부가세 ${summary.vatFormatted} (${summary.vatMode}) · 과업기간 <b>${summary.durationLabel}</b></span>
    `;

    const badge = el('top-status-badge');
    badge.textContent = validation.status;
    badge.className = 'badge ' + (validation.passed ? 'badge--status-ok' : 'badge--status-warn');

    const vbox = el('validation-box');
    if (validation.passed) {
      vbox.className = 'validation-box';
      vbox.innerHTML = `<h3>자동 조립 완료 · 서류 4종 수치·일자·기술자 정합성 통과</h3><p style="margin:0;font-size:0.84rem;">발주처 특기 시방·예정공정표 첨부 여부와 대표 건축사 직인 날인만 최종 확인한 뒤 제출하세요.</p>`;
    } else {
      vbox.className = 'validation-box is-pending';
      vbox.innerHTML = `<h3>사람 확인(검수 대기) · ${validation.issueCount}건의 누락·모순 항목이 발견되었습니다</h3>
        <ul>${validation.issues.map((i) => `<li>${i.message}</li>`).join('')}</ul>`;
    }

    el('doc-preview').innerHTML = rendered.combinedHtml;
    applyTabFilter();
  }

  document.addEventListener('input', (e) => {
    const t = e.target;
    if (t && t.dataset && t.dataset.engIdx !== undefined) {
      const idx = Number(t.dataset.engIdx);
      engineers[idx][t.dataset.engKey] = t.value;
    }
    refreshPreview();
  });

  document.addEventListener('click', (e) => {
    const t = e.target;
    if (!t) return;
    if (t.dataset && t.dataset.engRemove !== undefined) {
      engineers.splice(Number(t.dataset.engRemove), 1);
      renderEngineerInputs();
      refreshPreview();
    }
    if (t.matches('[role="tab"]')) {
      activeTab = t.dataset.tab || 'all';
      document.querySelectorAll('[role="tab"]').forEach((btn) => btn.setAttribute('aria-selected', String(btn === t)));
      applyTabFilter();
    }
  });

  el('add-engineer-btn').addEventListener('click', () => {
    engineers.push({ field: '건축계획', name: '', position: '참여기술자', license: '', task: '실시설계 도서 작성' });
    renderEngineerInputs();
    refreshPreview();
  });

  el('import-json-input').addEventListener('change', async (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const text = await file.text();
    const parsed = JSON.parse(text);
    applyFormData(parsed);
    el('save-log').textContent = `외부 파일 읽기 전용 불러오기 완료: ${file.name} (외부 원본 파일은 변경하지 않음)`;
  });

  el('download-doc-btn').addEventListener('click', () => {
    const data = collectFormData();
    const summary = calculateContractSummary(data);
    const validation = validateCommencementInput(data, summary);
    const html = '\ufeff' + buildStandaloneExportDocument(data, summary, validation, true);
    const blob = new Blob([html], { type: 'application/msword;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = (data.projectName || '착수계_4종패키지').replace(/[\\/:*?"<>|\s]+/g, '_') + '.doc';
    a.click();
    URL.revokeObjectURL(a.href);
  });

  el('print-btn').addEventListener('click', () => window.print());

  el('save-package-btn').addEventListener('click', async () => {
    const data = collectFormData();
    if (DEFAULT_SAMPLES) {
      const jsonBlob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(jsonBlob);
      a.download = (data.projectName || '착수계_프로젝트').replace(/[\\/:*?"<>|\s]+/g, '_') + '.json';
      a.click();
      URL.revokeObjectURL(a.href);
      el('save-log').textContent = '단일 HTML 모드: 프로젝트 기준 JSON 파일을 다운로드했습니다.';
      return;
    }
    const res = await fetch('/api/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const out = await res.json();
    if (out.ok) {
      const h = out.saved.html;
      el('save-log').textContent = h.duplicate
        ? `동일 SHA-256 내용 감지: 새로 덮어쓰지 않고 기존 ${h.savedFile} (${h.sha256.slice(0, 12)}…) 유지`
        : `저장 완료: output/${h.savedFile} · output/${out.saved.doc.savedFile} (SHA-256: ${h.sha256.slice(0, 12)}…)`;
    }
  });

  async function init() {
    const select = el('sample-select');
    if (DEFAULT_SAMPLES) {
      Object.keys(DEFAULT_SAMPLES).forEach((name) => {
        const opt = document.createElement('option');
        opt.value = name;
        opt.textContent = name;
        select.appendChild(opt);
      });
      el('load-sample-btn').addEventListener('click', () => {
        const chosen = DEFAULT_SAMPLES[select.value];
        if (chosen) applyFormData(chosen);
      });
      const firstKey = Object.keys(DEFAULT_SAMPLES)[0];
      if (firstKey) applyFormData(DEFAULT_SAMPLES[firstKey]);
      return;
    }
    const stateRes = await fetch('/api/state');
    const state = await stateRes.json();
    (state.samples || []).forEach((name) => {
      const opt = document.createElement('option');
      opt.value = name;
      opt.textContent = name;
      select.appendChild(opt);
    });
    async function loadSelectedSample(name) {
      const r = await fetch('/api/sample?file=' + encodeURIComponent(name));
      const j = await r.json();
      if (j.ok) applyFormData(j.data);
    }
    el('load-sample-btn').addEventListener('click', () => {
      if (select.value) loadSelectedSample(select.value);
    });
    if (state.samples && state.samples[0]) {
      await loadSelectedSample(state.samples[0]);
    }
  }

  init();
})();
