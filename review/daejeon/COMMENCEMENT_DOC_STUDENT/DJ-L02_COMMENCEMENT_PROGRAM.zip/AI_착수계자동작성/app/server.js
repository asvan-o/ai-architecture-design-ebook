// 로컬 전용 착수계·행정서류 4종 생성 서버 (외부 API·AI 크레딧 호출 0회)
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { calculateContractSummary } = require('./calculator');
const { validateCommencementInput } = require('./validator');
const { renderFourDocuments, buildStandaloneExportDocument } = require('./templates');
const rules = require('./rules.json');

const ROOT = path.resolve(__dirname, '..');
const UI_DIR = path.join(__dirname, 'ui');
const SAMPLES_DIR = path.join(ROOT, 'samples');
const PROJECTS_DIR = path.join(ROOT, 'projects');
const OUTPUT_DIR = path.join(ROOT, 'output');

for (const dir of [SAMPLES_DIR, PROJECTS_DIR, OUTPUT_DIR]) {
  fs.mkdirSync(dir, { recursive: true });
}

function isIgnoredTempFile(name) {
  const lower = name.toLowerCase();
  return (
    lower.endsWith('.tmp') ||
    lower.endsWith('.part') ||
    lower.endsWith('.crdownload') ||
    name.startsWith('~$') ||
    name === '.gitkeep'
  );
}

function safeInsideRoot(targetPath) {
  const resolved = path.resolve(targetPath);
  if (!resolved.startsWith(ROOT + path.sep) && resolved !== ROOT) {
    throw new Error('실습 폴더 루트 밖 경로에는 접근하거나 저장할 수 없습니다.');
  }
  return resolved;
}

function sanitizeSlug(text) {
  return String(text || '착수계_초안')
    .trim()
    .replace(/[\\/:*?"<>|]/g, '_')
    .replace(/\s+/g, '_')
    .slice(0, 50) || '착수계_초안';
}

function sha256(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex');
}

// 기존 파일을 덮어쓰지 않고 동일 SHA-256이면 중복 안내, 내용이 다르면 _v02, _v03 부여
function writeVersionedFile(dir, baseSlug, ext, contentBuf) {
  safeInsideRoot(dir);
  const digest = sha256(contentBuf);
  const existing = fs.readdirSync(dir).filter((f) => !isIgnoredTempFile(f) && f.endsWith(ext));
  for (const file of existing) {
    if (file === baseSlug + ext || file.startsWith(baseSlug + '_v')) {
      const prevBytes = fs.readFileSync(path.join(dir, file));
      if (sha256(prevBytes) === digest) {
        return { savedFile: file, duplicate: true, sha256: digest, versioned: false };
      }
    }
  }
  let candidate = baseSlug + ext;
  let version = 2;
  let versioned = false;
  while (fs.existsSync(path.join(dir, candidate))) {
    candidate = `${baseSlug}_v${String(version).padStart(2, '0')}${ext}`;
    version++;
    versioned = true;
  }
  fs.writeFileSync(path.join(dir, candidate), contentBuf);
  return { savedFile: candidate, duplicate: false, sha256: digest, versioned };
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let total = 0;
    req.on('data', (chunk) => {
      total += chunk.length;
      if (total > 2 * 1024 * 1024) {
        reject(new Error('요청 크기가 2MB 제한을 초과했습니다.'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'));
      } catch {
        reject(new Error('올바른 JSON 형식이 아닙니다.'));
      }
    });
    req.on('error', reject);
  });
}

function sendJson(res, code, payload) {
  const body = Buffer.from(JSON.stringify(payload, null, 2), 'utf8');
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
};

function createAppServer() {
  return http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url || '/', 'http://127.0.0.1');
      if (req.method === 'GET' && url.pathname === '/api/state') {
        const samples = fs
          .readdirSync(SAMPLES_DIR)
          .filter((f) => f.endsWith('.json') && !isIgnoredTempFile(f))
          .sort();
        const outputs = fs
          .readdirSync(OUTPUT_DIR)
          .filter((f) => !isIgnoredTempFile(f))
          .sort();
        return sendJson(res, 200, { ok: true, rules, samples, outputs, runtimeCredits: 0 });
      }

      if (req.method === 'GET' && url.pathname === '/api/sample') {
        const name = path.basename(url.searchParams.get('file') || '');
        if (!name.endsWith('.json') || isIgnoredTempFile(name)) {
          return sendJson(res, 400, { ok: false, error: '유효한 샘플 JSON 파일명을 지정하세요.' });
        }
        const target = safeInsideRoot(path.join(SAMPLES_DIR, name));
        if (!fs.existsSync(target)) {
          return sendJson(res, 404, { ok: false, error: '샘플 파일을 찾을 수 없습니다.' });
        }
        const data = JSON.parse(fs.readFileSync(target, 'utf8'));
        const summary = calculateContractSummary(data);
        const validation = validateCommencementInput(data, summary);
        const rendered = renderFourDocuments(data, summary, validation);
        return sendJson(res, 200, { ok: true, file: name, data, summary, validation, rendered });
      }

      if (req.method === 'POST' && url.pathname === '/api/preview') {
        const data = await readJsonBody(req);
        const summary = calculateContractSummary(data);
        const validation = validateCommencementInput(data, summary);
        const rendered = renderFourDocuments(data, summary, validation);
        return sendJson(res, 200, { ok: true, summary, validation, rendered });
      }

      if (req.method === 'POST' && url.pathname === '/api/save') {
        const data = await readJsonBody(req);
        const summary = calculateContractSummary(data);
        const validation = validateCommencementInput(data, summary);
        const slug = sanitizeSlug(data.projectName);
        const jsonBuf = Buffer.from(JSON.stringify(data, null, 2) + '\n', 'utf8');
        const htmlBuf = Buffer.from(buildStandaloneExportDocument(data, summary, validation, false), 'utf8');
        const docBuf = Buffer.from('\ufeff' + buildStandaloneExportDocument(data, summary, validation, true), 'utf8');

        const savedProject = writeVersionedFile(PROJECTS_DIR, slug, '.json', jsonBuf);
        const savedHtml = writeVersionedFile(OUTPUT_DIR, slug + '_4종패키지', '.html', htmlBuf);
        const savedDoc = writeVersionedFile(OUTPUT_DIR, slug + '_4종패키지', '.doc', docBuf);
        const outputs = fs.readdirSync(OUTPUT_DIR).filter((f) => !isIgnoredTempFile(f)).sort();

        return sendJson(res, 200, {
          ok: true,
          summary,
          validation,
          saved: { project: savedProject, html: savedHtml, doc: savedDoc },
          outputs,
        });
      }

      // Serve UI assets
      const reqFile = url.pathname === '/' ? 'index.html' : url.pathname.slice(1);
      if (['calculator.js', 'validator.js', 'templates.js', 'rules.json'].includes(reqFile)) {
        const helperPath = safeInsideRoot(path.join(__dirname, reqFile));
        res.writeHead(200, { 'Content-Type': MIME[path.extname(helperPath)] || 'text/plain; charset=utf-8' });
        return res.end(fs.readFileSync(helperPath));
      }
      const uiTarget = safeInsideRoot(path.join(UI_DIR, reqFile));
      if (fs.existsSync(uiTarget) && fs.statSync(uiTarget).isFile()) {
        res.writeHead(200, { 'Content-Type': MIME[path.extname(uiTarget)] || 'application/octet-stream' });
        return res.end(fs.readFileSync(uiTarget));
      }
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Not Found');
    } catch (err) {
      sendJson(res, 500, { ok: false, error: err.message || '서버 오류' });
    }
  });
}

if (require.main === module) {
  const port = Number(process.env.PORT || rules.port || 4175);
  const server = createAppServer();
  server.listen(port, '127.0.0.1', () => {
    console.log(`[AI_착수계자동작성] 로컬 실행 중: http://127.0.0.1:${port}/`);
  });
}

module.exports = { createAppServer, writeVersionedFile, isIgnoredTempFile };
