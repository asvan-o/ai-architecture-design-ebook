@echo off
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :4176 ^| findstr LISTENING') do taskkill /f /pid %%a >nul 2>&1
echo Server on 4176 stopped.
