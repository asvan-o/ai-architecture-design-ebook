// 스페이스 프로그램 2페이지 분리 보고서(HTML / Word .doc) 및 엑셀 CSV 출력기
function esc(v) {
  return String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function buildSpaceSheetsHtml(input, summary, validation) {
  const banner = !validation.ready
    ? `<div class="doc-warn"><strong>[사람 확인(검수 대기)]</strong><ul>${validation.warnings.map((w) => `<li>${esc(w)}</li>`).join('')}</ul></div>`
    : `<div class="doc-ok"><strong>[자동 집계 완료]</strong> 목표 연면적 허용 범위(±${summary.tolerancePct}%) 이내로 전용·공용 배분이 검증되었습니다.</div>`;

  const deltaSign = summary.deltaGrossM2 > 0 ? '+' : '';
  const sheet1 = `<section class="doc-sheet" data-sheet="summary">
    <div class="doc-badge">SPACE PROGRAM · SHEET 01 / SUMMARY</div>
    <h1 class="doc-title">건축 기획 스페이스 프로그램 총괄 요약표</h1>
    ${banner}
    <table class="doc-table">
      <tbody>
        <tr><th>프로젝트명</th><td colspan="3"><strong>${esc(input.projectName || '미기재')}</strong></td></tr>
        <tr><th>발주처 / 건축주</th><td>${esc(input.clientName || '-')}</td><th>주용도 분류</th><td>${esc(input.buildingUse || '-')}</td></tr>
        <tr><th>전용면적 합계 (Net)</th><td><strong>${summary.totalNetM2.toLocaleString()} ㎡</strong> (${summary.totalNetPyeong.toLocaleString()} 평)</td><th>계획 공용률</th><td>${summary.coreRatioPct}% (공용 ${summary.estimatedCoreM2.toLocaleString()} ㎡)</td></tr>
        <tr><th>예상 총 연면적 (Gross)</th><td><strong>${summary.estimatedGrossM2.toLocaleString()} ㎡</strong> (${summary.estimatedGrossPyeong.toLocaleString()} 평)</td><th>목표 연면적 대비</th><td>${summary.targetGrossM2.toLocaleString()} ㎡ 대비 <strong>${deltaSign}${summary.deltaGrossM2.toLocaleString()} ㎡ (${deltaSign}${summary.deltaPct}%)</strong></td></tr>
        <tr><th>기획 메모</th><td colspan="3">${esc(input.note || '-')}</td></tr>
      </tbody>
    </table>

    <h2 class="doc-sub">1. 층별 전용면적 배분 집계 (Group-By Floor)</h2>
    <table class="doc-table">
      <thead><tr><th>층 구분</th><th>실 종류 수</th><th>총 개소수</th><th>층별 전용소계 (㎡)</th><th>평 환산 (평)</th><th>전용 비중 (%)</th></tr></thead>
      <tbody>
        ${summary.byFloor.map((f) => `<tr><td class="c"><strong>${esc(f.floor)}</strong></td><td class="c">${f.roomTypes}종</td><td class="c">${f.roomUnits}실</td><td class="r">${f.netM2.toLocaleString()}</td><td class="r">${f.netPyeong.toLocaleString()}</td><td class="r">${f.sharePct}%</td></tr>`).join('')}
      </tbody>
    </table>

    <h2 class="doc-sub">2. 기능 존(Zone)별 구성 비율</h2>
    <table class="doc-table">
      <thead><tr><th>존(Zone) 구분</th><th>전용 소계 (㎡)</th><th>평 환산 (평)</th><th>전용 비중 (%)</th></tr></thead>
      <tbody>
        ${summary.byZone.map((z) => `<tr><td><strong>${esc(z.zone)}</strong></td><td class="r">${z.netM2.toLocaleString()}</td><td class="r">${z.netPyeong.toLocaleString()}</td><td class="r">${z.sharePct}%</td></tr>`).join('')}
      </tbody>
    </table>
    <p class="doc-foot">※ 본 면적표는 초기 기획·계획설계 단계의 순수 산술 시뮬레이션 자료이며, 인허가 법정 바닥면적·연면적·건폐율·용적률은 관할 법규 및 CAD 실측 도면으로 별도 확정합니다.</p>
  </section>`;

  const sheet2 = `<section class="doc-sheet" data-sheet="rooms">
    <div class="doc-badge">SPACE PROGRAM · SHEET 02 / ROOM SCHEDULE</div>
    <h1 class="doc-title">층별 · 실별 상세 스페이스 프로그램 면적표</h1>
    <table class="doc-table">
      <thead>
        <tr><th style="width:8%">연번</th><th style="width:10%">층</th><th style="width:16%">기능 존</th><th style="width:24%">실 명칭</th><th style="width:12%">단위전용(㎡)</th><th style="width:8%">개소</th><th style="width:12%">소계(㎡/평)</th><th>비고</th></tr>
      </thead>
      <tbody>
        ${summary.rooms.map((r) => `<tr>
          <td class="c">${r.index}</td>
          <td class="c">${esc(r.floor || '미지정')}</td>
          <td>${esc(r.zone)}</td>
          <td><strong>${esc(r.name || '[실명 누락]')}</strong></td>
          <td class="r">${r.unitAreaM2.toLocaleString()}</td>
          <td class="c">${r.count}</td>
          <td class="r"><strong>${r.subtotalM2.toLocaleString()}</strong><br/><small>(${r.subtotalPyeong}평)</small></td>
          <td>${esc(r.remark)}</td>
        </tr>`).join('')}
      </tbody>
    </table>
  </section>`;

  return [sheet1, sheet2];
}

function buildStandaloneSpaceReport(input, summary, validation, forWord = false) {
  const sheets = buildSpaceSheetsHtml(input, summary, validation);
  const wordBreak = '<br clear="all" style="mso-special-character:line-break; page-break-before:always;" />';
  const joined = forWord ? sheets.join('\n' + wordBreak + '\n') : sheets.join('\n');
  const headOpen = forWord
    ? '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40" lang="ko"><head><meta charset="utf-8"><!--[if gte mso 9]><xml><w:WordDocument><w:View>Print</w:View><w:Zoom>100</w:Zoom><w:DoNotOptimizeForBrowser/></w:WordDocument></xml><![endif]-->'
    : '<!doctype html><html lang="ko"><head><meta charset="utf-8">';
  return `${headOpen}<title>${esc(input.projectName || '스페이스프로그램')}</title><style>
    @page { size: A4 portrait; margin: 15mm; }
    @page WordSection1 { size: 210mm 297mm; margin: 15mm; }
    body { font-family: "Malgun Gothic", sans-serif; color: #111827; margin: 0; font-size: 10pt; line-height: 1.45; }
    div.WordSection1 { page: WordSection1; }
    .doc-sheet { box-sizing: border-box; }
    .doc-sheet + .doc-sheet { page-break-before: always; break-before: page; }
    .doc-badge { font-size: 8.5pt; color: #0f766e; font-weight: 700; letter-spacing: 0.06em; }
    .doc-title { font-size: 16pt; margin: 4pt 0 10pt; border-bottom: 2px solid #0f172a; padding-bottom: 6pt; }
    .doc-sub { font-size: 11.5pt; margin: 14pt 0 6pt; color: #1e293b; }
    .doc-table { width: 100%; border-collapse: collapse; margin-bottom: 8pt; }
    .doc-table thead { display: table-header-group; }
    .doc-table tr { page-break-inside: avoid; break-inside: avoid; }
    .doc-table th, .doc-table td { border: 1px solid #475569; padding: 5pt 6pt; font-size: 9.5pt; vertical-align: middle; }
    .doc-table th { background: #f1f5f9; text-align: center; font-weight: 700; }
    .c { text-align: center; } .r { text-align: right; }
    .doc-warn { border: 1.5px solid #dc2626; background: #fef2f2; color: #991b1b; padding: 7pt 9pt; margin-bottom: 8pt; font-size: 9pt; }
    .doc-ok { border: 1.5px solid #0f766e; background: #f0fdfa; color: #115e59; padding: 7pt 9pt; margin-bottom: 8pt; font-size: 9pt; }
    .doc-foot { font-size: 8.5pt; color: #475569; margin-top: 10pt; }
  </style></head><body><div class="WordSection1">${joined}</div></body></html>`;
}

function buildSpaceCsv(input, summary) {
  const q = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const lines = [
    ['프로젝트명', input.projectName || '', '목표연면적(㎡)', summary.targetGrossM2, '계획공용률(%)', summary.coreRatioPct].map(q).join(','),
    ['전용합계(㎡)', summary.totalNetM2, '공용예상(㎡)', summary.estimatedCoreM2, '예상총연면적(㎡)', summary.estimatedGrossM2].map(q).join(','),
    '',
    ['연번', '층', '기능존', '실명칭', '단위전용(㎡)', '개소수', '전용소계(㎡)', '전용소계(평)', '비고'].map(q).join(','),
    ...summary.rooms.map((r) => [r.index, r.floor, r.zone, r.name, r.unitAreaM2, r.count, r.subtotalM2, r.subtotalPyeong, r.remark].map(q).join(','))
  ];
  return '\uFEFF' + lines.join('\r\n') + '\r\n';
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { buildSpaceSheetsHtml, buildStandaloneSpaceReport, buildSpaceCsv };
}
