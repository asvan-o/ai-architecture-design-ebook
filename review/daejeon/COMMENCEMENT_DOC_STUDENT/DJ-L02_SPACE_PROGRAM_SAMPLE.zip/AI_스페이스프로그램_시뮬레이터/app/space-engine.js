// 건축 기획 스페이스 프로그램(실별 면적표) 다차원 배열 집계 & 목표 연면적 역산 엔진
const PYEONG_FACTOR = 0.3025;
const FLOOR_ORDER = ['B3', 'B2', 'B1', '1F', '2F', '3F', '4F', '5F', '6F', 'RF'];
const ZONE_PALETTE = {
  '업무·주용도': '#173f39',
  '회의·협업': '#1d4e68',
  '지원·편의': '#b45309',
  '공용·코어': '#64748b'
};

function round2(n) {
  return Math.round((Number(n) || 0) * 100) / 100;
}

function toPyeong(m2) {
  return round2((Number(m2) || 0) * PYEONG_FACTOR);
}

function floorRank(f) {
  const key = String(f || '').trim().toUpperCase();
  const idx = FLOOR_ORDER.indexOf(key);
  return idx >= 0 ? idx : 999;
}

function calculateSpaceProgram(input) {
  const rooms = Array.isArray(input.rooms) ? input.rooms : [];
  const coreRatioPct = Math.min(80, Math.max(0, Number(input.coreRatioPct) || 0));
  const targetGrossM2 = Math.max(0, Number(input.targetGrossM2) || 0);
  const tolerancePct = Math.max(1, Number(input.tolerancePct) || 5);

  const normalizedRooms = rooms.map((r, idx) => {
    const unitAreaM2 = round2(Number(r.unitAreaM2) || 0);
    const count = Math.max(0, Math.trunc(Number(r.count) || 0));
    const subtotalM2 = round2(unitAreaM2 * count);
    return {
      index: idx + 1,
      floor: String(r.floor || '').trim(),
      zone: String(r.zone || '업무·주용도').trim(),
      name: String(r.name || '').trim(),
      unitAreaM2,
      count,
      subtotalM2,
      subtotalPyeong: toPyeong(subtotalM2),
      remark: String(r.remark || '').trim()
    };
  });

  const totalNetM2 = round2(normalizedRooms.reduce((sum, r) => sum + r.subtotalM2, 0));
  const totalNetPyeong = toPyeong(totalNetM2);
  const ratioDecimal = coreRatioPct / 100;
  const estimatedGrossM2 = ratioDecimal >= 0.95 ? totalNetM2 : round2(totalNetM2 / (1 - ratioDecimal));
  const estimatedGrossPyeong = toPyeong(estimatedGrossM2);
  const estimatedCoreM2 = round2(estimatedGrossM2 - totalNetM2);
  const estimatedCorePyeong = toPyeong(estimatedCoreM2);

  // Group-By 1: 층별 소계
  const floorMap = new Map();
  for (const r of normalizedRooms) {
    const key = r.floor || '미지정';
    const prev = floorMap.get(key) || { floor: key, roomTypes: 0, roomUnits: 0, netM2: 0 };
    prev.roomTypes += 1;
    prev.roomUnits += r.count;
    prev.netM2 = round2(prev.netM2 + r.subtotalM2);
    floorMap.set(key, prev);
  }
  const byFloor = [...floorMap.values()]
    .sort((a, b) => floorRank(a.floor) - floorRank(b.floor) || a.floor.localeCompare(b.floor))
    .map((f) => ({
      ...f,
      netPyeong: toPyeong(f.netM2),
      sharePct: totalNetM2 > 0 ? round2((f.netM2 / totalNetM2) * 100) : 0
    }));

  // Group-By 2: 존(성격)별 소계
  const zoneMap = new Map();
  for (const r of normalizedRooms) {
    const key = r.zone || '기타';
    zoneMap.set(key, round2((zoneMap.get(key) || 0) + r.subtotalM2));
  }
  const byZone = [...zoneMap.entries()].map(([zone, netM2]) => ({
    zone,
    netM2,
    netPyeong: toPyeong(netM2),
    sharePct: totalNetM2 > 0 ? round2((netM2 / totalNetM2) * 100) : 0,
    color: ZONE_PALETTE[zone] || '#475569'
  }));

  // Goal-Seek 역산: 목표 연면적 달성까지 증감해야 할 전용면적(Net)
  const deltaGrossM2 = round2(estimatedGrossM2 - targetGrossM2);
  const deltaPct = targetGrossM2 > 0 ? round2((deltaGrossM2 / targetGrossM2) * 100) : 0;
  const targetNetAtRatioM2 = round2(targetGrossM2 * (1 - ratioDecimal));
  const netAdjustmentNeededM2 = round2(targetNetAtRatioM2 - totalNetM2);

  return {
    rooms: normalizedRooms,
    totalNetM2,
    totalNetPyeong,
    coreRatioPct,
    estimatedCoreM2,
    estimatedCorePyeong,
    estimatedGrossM2,
    estimatedGrossPyeong,
    targetGrossM2,
    targetGrossPyeong: toPyeong(targetGrossM2),
    tolerancePct,
    deltaGrossM2,
    deltaGrossPyeong: toPyeong(deltaGrossM2),
    deltaPct,
    targetNetAtRatioM2,
    netAdjustmentNeededM2,
    netAdjustmentNeededPyeong: toPyeong(netAdjustmentNeededM2),
    byFloor,
    byZone
  };
}

function validateSpaceProgram(input, summary) {
  const warnings = [];
  if (!String(input.projectName || '').trim()) warnings.push('프로젝트명이 비어 있습니다.');
  if (summary.targetGrossM2 <= 0) warnings.push('목표 연면적(㎡)이 입력되지 않아 적정 범위 판정을 확정할 수 없습니다.');
  if (summary.rooms.length === 0) warnings.push('최소 1개 이상의 실(Room) 항목이 필요합니다.');

  summary.rooms.forEach((r) => {
    if (!r.name) warnings.push(`${r.index}번째 행의 실 이름이 비어 있습니다.`);
    if (!r.floor) warnings.push(`"${r.name || r.index + '행'}"의 배치 층(예: 1F, 2F)이 지정되지 않았습니다.`);
    if (r.unitAreaM2 <= 0 || r.count <= 0) warnings.push(`"${r.name || r.index + '행'}"의 면적 또는 개소수가 0 이하입니다.`);
  });

  if (summary.coreRatioPct < 10 || summary.coreRatioPct > 55) {
    warnings.push(`계획 공용률(${summary.coreRatioPct}%)이 일반 건축 범위(10%~55%)를 벗어났습니다. 코어·복도 비율을 재확인하세요.`);
  }
  if (summary.targetGrossM2 > 0 && Math.abs(summary.deltaPct) > summary.tolerancePct) {
    const dir = summary.deltaGrossM2 > 0 ? '초과' : '미달';
    warnings.push(
      `예상 총 연면적(${summary.estimatedGrossM2.toLocaleString()}㎡)이 목표(${summary.targetGrossM2.toLocaleString()}㎡) 대비 ${Math.abs(summary.deltaPct)}% ${dir}했습니다(허용 ±${summary.tolerancePct}%). 전용면적을 약 ${Math.abs(summary.netAdjustmentNeededM2).toLocaleString()}㎡(${Math.abs(summary.netAdjustmentNeededPyeong)}평) ${summary.netAdjustmentNeededM2 < 0 ? '축소' : '확충'}하거나 공용률을 조정해 주세요.`
    );
  }

  return {
    status: warnings.length === 0 ? '자동 집계 완료' : '사람 확인(검수 대기)',
    ready: warnings.length === 0,
    warnings
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PYEONG_FACTOR, round2, toPyeong, calculateSpaceProgram, validateSpaceProgram };
}
