const EMBEDDED_SAMPLES = {
  "01_성수동_디자인사옥_기획안.json": {
    "projectName": "성수동 크리에이티브 스튜디오 사옥 기획설계",
    "clientName": "(주)아틀리에성수",
    "buildingUse": "업무시설 · 근린생활시설",
    "targetGrossM2": 660,
    "coreRatioPct": 28,
    "tolerancePct": 5,
    "note": "1층 라운지·쇼룸 + 2~4층 디자인 스튜디오 구성안",
    "rooms": [
      {
        "floor": "1F",
        "zone": "지원·편의",
        "name": "로비 및 브랜드 라운지",
        "unitAreaM2": 68,
        "count": 1,
        "remark": "방문객 맞이·전시 겸용"
      },
      {
        "floor": "1F",
        "zone": "회의·협업",
        "name": "고객 미팅룸 A",
        "unitAreaM2": 24,
        "count": 2,
        "remark": "8인 기준 방음 파티션"
      },
      {
        "floor": "2F",
        "zone": "업무·주용도",
        "name": "설계 1팀 오픈 스튜디오",
        "unitAreaM2": 118,
        "count": 1,
        "remark": "모형 작업대 포함"
      },
      {
        "floor": "2F",
        "zone": "지원·편의",
        "name": "샘플 자재 라이브러리",
        "unitAreaM2": 26,
        "count": 1,
        "remark": "수납 월 시스템"
      },
      {
        "floor": "3F",
        "zone": "업무·주용도",
        "name": "설계 2팀 오픈 스튜디오",
        "unitAreaM2": 118,
        "count": 1,
        "remark": "24석 데스크 배치"
      },
      {
        "floor": "3F",
        "zone": "회의·협업",
        "name": "집중 포커스 부스",
        "unitAreaM2": 8,
        "count": 2,
        "remark": "화상회의 겸용"
      },
      {
        "floor": "4F",
        "zone": "회의·협업",
        "name": "타운홀 대회의실",
        "unitAreaM2": 56,
        "count": 1,
        "remark": "전 직원 크리틱 공간"
      },
      {
        "floor": "4F",
        "zone": "지원·편의",
        "name": "임원실 및 리프레시 탕비홀",
        "unitAreaM2": 34,
        "count": 1,
        "remark": "루프 테라스 연계"
      }
    ]
  },
  "02_연희동_근생클리닉_기획안.json": {
    "projectName": "연희동 웰니스 클리닉 근생 신축 기획안",
    "clientName": "연희메디컬",
    "buildingUse": "제1종 근린생활시설(의원)",
    "targetGrossM2": 495,
    "coreRatioPct": 30,
    "tolerancePct": 5,
    "note": "1층 약국·카페 + 2~3층 외래진료 및 물리치료실 구성",
    "rooms": [
      {
        "floor": "1F",
        "zone": "지원·편의",
        "name": "전면 베이커리 카페 임대존",
        "unitAreaM2": 82,
        "count": 1,
        "remark": "가로 활성화 전면배치"
      },
      {
        "floor": "1F",
        "zone": "지원·편의",
        "name": "처방 조제 약국",
        "unitAreaM2": 38,
        "count": 1,
        "remark": "주출입구 인접"
      },
      {
        "floor": "2F",
        "zone": "업무·주용도",
        "name": "진료실",
        "unitAreaM2": 18,
        "count": 3,
        "remark": "원장 3인 체제"
      },
      {
        "floor": "2F",
        "zone": "회의·협업",
        "name": "접수·대기 라운지 및 상담실",
        "unitAreaM2": 58,
        "count": 1,
        "remark": "자연채광 중정면"
      },
      {
        "floor": "3F",
        "zone": "업무·주용도",
        "name": "도수·물리치료 베드존",
        "unitAreaM2": 76,
        "count": 1,
        "remark": "커튼 구획 8베드"
      },
      {
        "floor": "3F",
        "zone": "지원·편의",
        "name": "원내 스태프 휴게·탈의실",
        "unitAreaM2": 34,
        "count": 1,
        "remark": "샤워 부스 포함"
      }
    ]
  },
  "03_복합라운지_면적초과_검수대기.json": {
    "projectName": "한남동 복합문화라운지 증축 기획안 (초과 점검용)",
    "clientName": "한남컬처랩",
    "buildingUse": "문화 및 집회시설 · 근린생활시설",
    "targetGrossM2": 500,
    "coreRatioPct": 32,
    "tolerancePct": 5,
    "note": "건축주 요구 실 면적이 목표 연면적을 크게 초과하고 미지정 층이 섞인 검수 대기 예제",
    "rooms": [
      {
        "floor": "1F",
        "zone": "업무·주용도",
        "name": "메인 기획전시홀",
        "unitAreaM2": 145,
        "count": 1,
        "remark": "층고 4.5m 확보 희망"
      },
      {
        "floor": "2F",
        "zone": "업무·주용도",
        "name": "아트북 아카이브 살롱",
        "unitAreaM2": 120,
        "count": 1,
        "remark": "서가 하중 고려"
      },
      {
        "floor": "3F",
        "zone": "회의·협업",
        "name": "크리에이터 세미나룸",
        "unitAreaM2": 48,
        "count": 2,
        "remark": "가변형 폴딩도어"
      },
      {
        "floor": "",
        "zone": "지원·편의",
        "name": "수장고 및 준비실 (층 미정)",
        "unitAreaM2": 35,
        "count": 1,
        "remark": "층 위치 건축주 미확정"
      }
    ]
  }
};
let state = JSON.parse(JSON.stringify(EMBEDDED_SAMPLES['01_성수동_디자인사옥_기획안.json']));

function renderEditor() {
  document.getElementById('f-project').value = state.projectName || '';
  document.getElementById('f-client').value = state.clientName || '';
  document.getElementById('f-use').value = state.buildingUse || '';
  document.getElementById('f-target').value = state.targetGrossM2 ?? 660;
  document.getElementById('f-ratio').value = state.coreRatioPct ?? 28;
  document.getElementById('ratio-val').textContent = (state.coreRatioPct ?? 28) + '%';
  document.getElementById('f-note').value = state.note || '';

  const tbody = document.getElementById('room-tbody');
  tbody.innerHTML = '';
  state.rooms.forEach((r, idx) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><input data-k="floor" data-i="${idx}" value="${(r.floor || '').replace(/"/g, '&quot;')}" placeholder="1F" style="width:46px"/></td>
      <td><select data-k="zone" data-i="${idx}">
        ${['업무·주용도','회의·협업','지원·편의','공용·코어'].map(z => `<option value="${z}" ${r.zone===z?'selected':''}>${z}</option>`).join('')}
      </select></td>
      <td><input data-k="name" data-i="${idx}" value="${(r.name || '').replace(/"/g, '&quot;')}" placeholder="실 이름"/></td>
      <td><input type="number" step="1" data-k="unitAreaM2" data-i="${idx}" value="${r.unitAreaM2}" style="width:62px"/></td>
      <td><input type="number" step="1" min="1" data-k="count" data-i="${idx}" value="${r.count}" style="width:44px"/></td>
      <td><button type="button" data-del="${idx}" title="삭제" style="padding:3px 7px">✕</button></td>`;
    tbody.appendChild(tr);
  });
}

function refreshOutput() {
  const summary = calculateSpaceProgram(state);
  const validation = validateSpaceProgram(state, summary);

  document.getElementById('kpi-net').textContent = summary.totalNetM2.toLocaleString() + ' ㎡';
  document.getElementById('kpi-net-sub').textContent = summary.totalNetPyeong.toLocaleString() + ' 평 · ' + summary.rooms.length + '개 실군';
  document.getElementById('kpi-core').textContent = summary.estimatedCoreM2.toLocaleString() + ' ㎡';
  document.getElementById('kpi-core-sub').textContent = '공용률 ' + summary.coreRatioPct + '% (' + summary.estimatedCorePyeong + '평)';
  document.getElementById('kpi-gross').textContent = summary.estimatedGrossM2.toLocaleString() + ' ㎡';
  document.getElementById('kpi-gross-sub').textContent = summary.estimatedGrossPyeong.toLocaleString() + ' 평';

  const sign = summary.deltaGrossM2 > 0 ? '+' : '';
  document.getElementById('kpi-delta').textContent = sign + summary.deltaGrossM2.toLocaleString() + ' ㎡ (' + sign + summary.deltaPct + '%)';
  document.getElementById('kpi-delta').style.color = Math.abs(summary.deltaPct) > summary.tolerancePct ? '#dc2626' : '#0f766e';
  document.getElementById('kpi-delta-sub').textContent = summary.netAdjustmentNeededM2 >= 0
    ? '목표까지 전용 +' + summary.netAdjustmentNeededM2 + '㎡ 여유'
    : '목표 맞추려면 전용 ' + summary.netAdjustmentNeededM2 + '㎡ 감축';

  // Zone stacked bar
  const bar = document.getElementById('zone-bar');
  const leg = document.getElementById('zone-legend');
  bar.innerHTML = summary.byZone.map(z => `<div style="width:${z.sharePct}%;background:${z.color}" title="${z.zone}: ${z.netM2}㎡ (${z.sharePct}%)"></div>`).join('');
  leg.innerHTML = summary.byZone.map(z => `<span><i class="dot" style="background:${z.color}"></i><strong>${z.zone}</strong> ${z.netM2}㎡ (${z.sharePct}%)</span>`).join('');

  const statusBox = document.getElementById('status-box');
  if (validation.ready) {
    statusBox.className = 'status-ok';
    statusBox.innerHTML = '✓ [자동 집계 완료] 목표 연면적 오차 범위(±' + summary.tolerancePct + '%) 이내 · 요약표(1쪽) + 상세 면적표(2쪽) 분리 출력 준비 완료';
  } else {
    statusBox.className = 'status-warn';
    statusBox.innerHTML = '<strong>⚠ [사람 확인(검수 대기)] 아래 항목을 조정·확인하세요</strong><ul>' + validation.warnings.map(w => '<li>' + w + '</li>').join('') + '</ul>';
  }

  document.getElementById('sheets-preview').innerHTML = buildSpaceSheetsHtml(state, summary, validation).join('');
  return { summary, validation };
}

document.addEventListener('input', (e) => {
  const t = e.target;
  if (t.id === 'f-project') state.projectName = t.value;
  else if (t.id === 'f-client') state.clientName = t.value;
  else if (t.id === 'f-use') state.buildingUse = t.value;
  else if (t.id === 'f-target') state.targetGrossM2 = Number(t.value) || 0;
  else if (t.id === 'f-ratio') { state.coreRatioPct = Number(t.value) || 0; document.getElementById('ratio-val').textContent = state.coreRatioPct + '%'; }
  else if (t.id === 'f-note') state.note = t.value;
  else if (t.dataset.k !== undefined) {
    const idx = Number(t.dataset.i);
    const k = t.dataset.k;
    state.rooms[idx][k] = (k === 'unitAreaM2' || k === 'count') ? Number(t.value) : t.value;
  }
  refreshOutput();
});

document.addEventListener('click', (e) => {
  const del = e.target.closest('[data-del]');
  if (del) {
    state.rooms.splice(Number(del.dataset.del), 1);
    renderEditor();
    refreshOutput();
  }
});

document.getElementById('add-room-btn').addEventListener('click', () => {
  state.rooms.push({ floor: '2F', zone: '업무·주용도', name: '신규 계획실', unitAreaM2: 30, count: 1, remark: '' });
  renderEditor();
  refreshOutput();
});

document.getElementById('apply-sample-btn').addEventListener('click', () => {
  const key = document.getElementById('sample-select').value;
  state = JSON.parse(JSON.stringify(EMBEDDED_SAMPLES[key]));
  renderEditor();
  refreshOutput();
});

document.getElementById('json-file-input').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const parsed = JSON.parse(await file.text());
  state = parsed;
  renderEditor();
  refreshOutput();
  e.target.value = '';
});

function downloadBlob(filename, mime, content) {
  const blob = new Blob([content], { type: mime });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1500);
}

document.getElementById('csv-btn').addEventListener('click', () => {
  const { summary } = refreshOutput();
  downloadBlob((state.projectName || '스페이스프로그램') + '_면적표.csv', 'text/csv;charset=utf-8', buildSpaceCsv(state, summary));
});

document.getElementById('word-btn').addEventListener('click', () => {
  const { summary, validation } = refreshOutput();
  downloadBlob((state.projectName || '스페이스프로그램') + '_2쪽보고서.doc', 'application/msword;charset=utf-8', buildStandaloneSpaceReport(state, summary, validation, true));
});

document.getElementById('print-btn').addEventListener('click', () => {
  const { summary, validation } = refreshOutput();
  const html = buildStandaloneSpaceReport(state, summary, validation, false);
  let frame = document.getElementById('print-frame');
  if (frame) frame.remove();
  frame = document.createElement('iframe');
  frame.id = 'print-frame';
  frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
  document.body.appendChild(frame);
  frame.contentDocument.open();
  frame.contentDocument.write(html);
  frame.contentDocument.close();
  setTimeout(() => { frame.contentWindow.focus(); frame.contentWindow.print(); }, 180);
});

renderEditor();
refreshOutput();
