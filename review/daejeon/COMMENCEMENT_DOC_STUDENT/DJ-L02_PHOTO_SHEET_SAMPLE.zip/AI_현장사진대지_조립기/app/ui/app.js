const EMBEDDED_PHOTO_SAMPLES = {
  "01_성수동_현장검측_6컷_정상.json": {
    "meta": {
      "projectName": "성수동 근생 리모델링 현장 감리·시공 검측",
      "inspectDate": "2026-11-16",
      "inspector": "박준호 건축사 (감리자)",
      "contractor": "성수종합건설(주)",
      "layoutMode": 2
    },
    "items": [
      {
        "location": "옥상층 파라펫 코너부",
        "trade": "방수공사",
        "status": "보완 요청",
        "note": "우레탄 도막방수 치켜올림 높이 일부 부족(기준 300mm 대비 210mm 구간 확인)",
        "actionNote": "코너 보강포 재시공 후 치켜올림 300mm 이상 도막 재도포 요망",
        "dueDate": "2026-11-20",
        "dataUrl": "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22640%22%20height%3D%22480%22%20viewBox%3D%220%200%20640%20480%22%3E%0A%20%20%20%20%3Crect%20width%3D%22640%22%20height%3D%22480%22%20fill%3D%22%23e5e7eb%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2224%22%20y%3D%2224%22%20width%3D%22592%22%20height%3D%22432%22%20fill%3D%22%23f8fafc%22%20stroke%3D%22%2394a3b8%22%20stroke-width%3D%222%22%20rx%3D%228%22%2F%3E%0A%20%20%20%20%3Cline%20x1%3D%2224%22%20y1%3D%22240%22%20x2%3D%22616%22%20y2%3D%22240%22%20stroke%3D%22%23cbd5e1%22%20stroke-dasharray%3D%226%206%22%2F%3E%0A%20%20%20%20%3Cline%20x1%3D%22320%22%20y1%3D%2224%22%20x2%3D%22320%22%20y2%3D%22456%22%20stroke%3D%22%23cbd5e1%22%20stroke-dasharray%3D%226%206%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2288%22%20y%3D%2296%22%20width%3D%22464%22%20height%3D%22240%22%20fill%3D%22%23eef2f6%22%20stroke%3D%22%23dc2626%22%20stroke-width%3D%223%22%20rx%3D%226%22%2F%3E%0A%20%20%20%20%3Cpath%20d%3D%22M120%20300%20L240%20160%20L350%20265%20L430%20195%20L520%20300%20Z%22%20fill%3D%22%23dc2626%22%20opacity%3D%220.18%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2238%22%20y%3D%2238%22%20width%3D%22168%22%20height%3D%2234%22%20rx%3D%225%22%20fill%3D%22%230f172a%22%2F%3E%0A%20%20%20%20%3Ctext%20x%3D%2250%22%20y%3D%2260%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2215%22%20font-weight%3D%22700%22%20fill%3D%22%23ffffff%22%3ECUT-01%20%C2%B7%20%ED%98%84%EC%9E%A5%EA%B2%80%EC%B8%A1%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22215%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2223%22%20font-weight%3D%22800%22%20fill%3D%22%230f172a%22%3E%EC%98%A5%EC%83%81%20%ED%8C%8C%EB%9D%BC%ED%8E%AB%20%EC%9A%B0%EB%A0%88%ED%83%84%20%EB%B0%A9%EC%88%98%20%EC%B9%98%EC%BC%9C%EC%98%AC%EB%A6%BC%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22252%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2216%22%20fill%3D%22%23334155%22%3E%EC%9C%84%EC%B9%98%3A%20%EC%98%A5%EC%83%81%EC%B8%B5%20%EB%B6%81%EC%B8%A1%20%EC%BD%94%EB%84%88%3C%2Ftext%3E%0A%20%20%20%20%3Crect%20x%3D%22220%22%20y%3D%22366%22%20width%3D%22200%22%20height%3D%2238%22%20rx%3D%2219%22%20fill%3D%22%23dc2626%22%2F%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22391%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2215%22%20font-weight%3D%22800%22%20fill%3D%22%23ffffff%22%3E%ED%8C%90%EC%A0%95%3A%20%EB%B3%B4%EC%99%84%20%EC%9A%94%EC%B2%AD%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22598%22%20y%3D%22444%22%20text-anchor%3D%22end%22%20font-family%3D%22monospace%22%20font-size%3D%2213%22%20fill%3D%22%23475569%22%3E2026-11-16%20SITE-CAM%204%3A3%3C%2Ftext%3E%0A%20%20%3C%2Fsvg%3E"
      },
      {
        "location": "3층 남측 커튼월 창호 하단",
        "trade": "창호·코킹공사",
        "status": "정상 확인",
        "note": "외부 비오염성 실리콘 코킹 폭 12mm 및 백업재 충진 상태 양호",
        "actionNote": "",
        "dueDate": "",
        "dataUrl": "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22640%22%20height%3D%22480%22%20viewBox%3D%220%200%20640%20480%22%3E%0A%20%20%20%20%3Crect%20width%3D%22640%22%20height%3D%22480%22%20fill%3D%22%23e5e7eb%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2224%22%20y%3D%2224%22%20width%3D%22592%22%20height%3D%22432%22%20fill%3D%22%23f8fafc%22%20stroke%3D%22%2394a3b8%22%20stroke-width%3D%222%22%20rx%3D%228%22%2F%3E%0A%20%20%20%20%3Cline%20x1%3D%2224%22%20y1%3D%22240%22%20x2%3D%22616%22%20y2%3D%22240%22%20stroke%3D%22%23cbd5e1%22%20stroke-dasharray%3D%226%206%22%2F%3E%0A%20%20%20%20%3Cline%20x1%3D%22320%22%20y1%3D%2224%22%20x2%3D%22320%22%20y2%3D%22456%22%20stroke%3D%22%23cbd5e1%22%20stroke-dasharray%3D%226%206%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2288%22%20y%3D%2296%22%20width%3D%22464%22%20height%3D%22240%22%20fill%3D%22%23eef2f6%22%20stroke%3D%22%230f766e%22%20stroke-width%3D%223%22%20rx%3D%226%22%2F%3E%0A%20%20%20%20%3Cpath%20d%3D%22M120%20300%20L240%20160%20L350%20265%20L430%20195%20L520%20300%20Z%22%20fill%3D%22%230f766e%22%20opacity%3D%220.18%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2238%22%20y%3D%2238%22%20width%3D%22168%22%20height%3D%2234%22%20rx%3D%225%22%20fill%3D%22%230f172a%22%2F%3E%0A%20%20%20%20%3Ctext%20x%3D%2250%22%20y%3D%2260%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2215%22%20font-weight%3D%22700%22%20fill%3D%22%23ffffff%22%3ECUT-02%20%C2%B7%20%ED%98%84%EC%9E%A5%EA%B2%80%EC%B8%A1%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22215%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2223%22%20font-weight%3D%22800%22%20fill%3D%22%230f172a%22%3E3%EC%B8%B5%20%EB%82%A8%EC%B8%A1%20%EC%95%8C%EB%A3%A8%EB%AF%B8%EB%8A%84%20%EC%B0%BD%ED%98%B8%20%EC%A3%BC%EC%9C%84%20%EC%BD%94%ED%82%B9%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22252%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2216%22%20fill%3D%22%23334155%22%3E%EC%9C%84%EC%B9%98%3A%203F%20%EB%82%A8%EC%B8%A1%20%EC%9E%85%EB%A9%B4%EC%B0%BD%3C%2Ftext%3E%0A%20%20%20%20%3Crect%20x%3D%22220%22%20y%3D%22366%22%20width%3D%22200%22%20height%3D%2238%22%20rx%3D%2219%22%20fill%3D%22%230f766e%22%2F%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22391%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2215%22%20font-weight%3D%22800%22%20fill%3D%22%23ffffff%22%3E%ED%8C%90%EC%A0%95%3A%20%EC%A0%95%EC%83%81%20%ED%99%95%EC%9D%B8%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22598%22%20y%3D%22444%22%20text-anchor%3D%22end%22%20font-family%3D%22monospace%22%20font-size%3D%2213%22%20fill%3D%22%23475569%22%3E2026-11-16%20SITE-CAM%204%3A3%3C%2Ftext%3E%0A%20%20%3C%2Fsvg%3E"
      },
      {
        "location": "내부 피난계단실 2~3층 구간",
        "trade": "금속·잡철공사",
        "status": "정상 확인",
        "note": "계단 손스침 난간 높이 900mm 및 벽체 이격거리 50mm 확보 확인",
        "actionNote": "",
        "dueDate": "",
        "dataUrl": "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22640%22%20height%3D%22480%22%20viewBox%3D%220%200%20640%20480%22%3E%0A%20%20%20%20%3Crect%20width%3D%22640%22%20height%3D%22480%22%20fill%3D%22%23e5e7eb%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2224%22%20y%3D%2224%22%20width%3D%22592%22%20height%3D%22432%22%20fill%3D%22%23f8fafc%22%20stroke%3D%22%2394a3b8%22%20stroke-width%3D%222%22%20rx%3D%228%22%2F%3E%0A%20%20%20%20%3Cline%20x1%3D%2224%22%20y1%3D%22240%22%20x2%3D%22616%22%20y2%3D%22240%22%20stroke%3D%22%23cbd5e1%22%20stroke-dasharray%3D%226%206%22%2F%3E%0A%20%20%20%20%3Cline%20x1%3D%22320%22%20y1%3D%2224%22%20x2%3D%22320%22%20y2%3D%22456%22%20stroke%3D%22%23cbd5e1%22%20stroke-dasharray%3D%226%206%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2288%22%20y%3D%2296%22%20width%3D%22464%22%20height%3D%22240%22%20fill%3D%22%23eef2f6%22%20stroke%3D%22%230f766e%22%20stroke-width%3D%223%22%20rx%3D%226%22%2F%3E%0A%20%20%20%20%3Cpath%20d%3D%22M120%20300%20L240%20160%20L350%20265%20L430%20195%20L520%20300%20Z%22%20fill%3D%22%230f766e%22%20opacity%3D%220.18%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2238%22%20y%3D%2238%22%20width%3D%22168%22%20height%3D%2234%22%20rx%3D%225%22%20fill%3D%22%230f172a%22%2F%3E%0A%20%20%20%20%3Ctext%20x%3D%2250%22%20y%3D%2260%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2215%22%20font-weight%3D%22700%22%20fill%3D%22%23ffffff%22%3ECUT-03%20%C2%B7%20%ED%98%84%EC%9E%A5%EA%B2%80%EC%B8%A1%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22215%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2223%22%20font-weight%3D%22800%22%20fill%3D%22%230f172a%22%3E%EB%82%B4%EB%B6%80%20%EA%B3%84%EB%8B%A8%EC%8B%A4%20%ED%95%B8%EB%93%9C%EB%A0%88%EC%9D%BC%20%EB%86%92%EC%9D%B4%C2%B7%EA%B3%A0%EC%A0%95%20%EC%83%81%ED%83%9C%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22252%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2216%22%20fill%3D%22%23334155%22%3E%EC%9C%84%EC%B9%98%3A%202F~3F%20%EA%B3%84%EB%8B%A8%EC%8B%A4%3C%2Ftext%3E%0A%20%20%20%20%3Crect%20x%3D%22220%22%20y%3D%22366%22%20width%3D%22200%22%20height%3D%2238%22%20rx%3D%2219%22%20fill%3D%22%230f766e%22%2F%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22391%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2215%22%20font-weight%3D%22800%22%20fill%3D%22%23ffffff%22%3E%ED%8C%90%EC%A0%95%3A%20%EC%A0%95%EC%83%81%20%ED%99%95%EC%9D%B8%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22598%22%20y%3D%22444%22%20text-anchor%3D%22end%22%20font-family%3D%22monospace%22%20font-size%3D%2213%22%20fill%3D%22%23475569%22%3E2026-11-16%20SITE-CAM%204%3A3%3C%2Ftext%3E%0A%20%20%3C%2Fsvg%3E"
      },
      {
        "location": "2층 서측 외벽 면",
        "trade": "단열공사",
        "status": "보완 요청",
        "note": "준불연 비드법 단열재 이음매 틈새(약 8mm) 벌어짐 2개소 발견",
        "actionNote": "단열재 정밀 밀착 보강 및 전용 우레탄폼 기밀 충진 후 재촬영",
        "dueDate": "2026-11-19",
        "dataUrl": "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22640%22%20height%3D%22480%22%20viewBox%3D%220%200%20640%20480%22%3E%0A%20%20%20%20%3Crect%20width%3D%22640%22%20height%3D%22480%22%20fill%3D%22%23e5e7eb%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2224%22%20y%3D%2224%22%20width%3D%22592%22%20height%3D%22432%22%20fill%3D%22%23f8fafc%22%20stroke%3D%22%2394a3b8%22%20stroke-width%3D%222%22%20rx%3D%228%22%2F%3E%0A%20%20%20%20%3Cline%20x1%3D%2224%22%20y1%3D%22240%22%20x2%3D%22616%22%20y2%3D%22240%22%20stroke%3D%22%23cbd5e1%22%20stroke-dasharray%3D%226%206%22%2F%3E%0A%20%20%20%20%3Cline%20x1%3D%22320%22%20y1%3D%2224%22%20x2%3D%22320%22%20y2%3D%22456%22%20stroke%3D%22%23cbd5e1%22%20stroke-dasharray%3D%226%206%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2288%22%20y%3D%2296%22%20width%3D%22464%22%20height%3D%22240%22%20fill%3D%22%23eef2f6%22%20stroke%3D%22%23dc2626%22%20stroke-width%3D%223%22%20rx%3D%226%22%2F%3E%0A%20%20%20%20%3Cpath%20d%3D%22M120%20300%20L240%20160%20L350%20265%20L430%20195%20L520%20300%20Z%22%20fill%3D%22%23dc2626%22%20opacity%3D%220.18%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2238%22%20y%3D%2238%22%20width%3D%22168%22%20height%3D%2234%22%20rx%3D%225%22%20fill%3D%22%230f172a%22%2F%3E%0A%20%20%20%20%3Ctext%20x%3D%2250%22%20y%3D%2260%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2215%22%20font-weight%3D%22700%22%20fill%3D%22%23ffffff%22%3ECUT-04%20%C2%B7%20%ED%98%84%EC%9E%A5%EA%B2%80%EC%B8%A1%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22215%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2223%22%20font-weight%3D%22800%22%20fill%3D%22%230f172a%22%3E%EC%99%B8%EB%B2%BD%20%EC%A4%80%EB%B6%88%EC%97%B0%20%EB%8B%A8%EC%97%B4%EC%9E%AC%20%EC%9D%B4%EC%9D%8C%EB%A7%A4%20%EB%B0%80%EC%B0%A9%20%EA%B2%80%EC%B8%A1%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22252%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2216%22%20fill%3D%22%23334155%22%3E%EC%9C%84%EC%B9%98%3A%202F%20%EC%84%9C%EC%B8%A1%20%EC%99%B8%EB%B2%BD%3C%2Ftext%3E%0A%20%20%20%20%3Crect%20x%3D%22220%22%20y%3D%22366%22%20width%3D%22200%22%20height%3D%2238%22%20rx%3D%2219%22%20fill%3D%22%23dc2626%22%2F%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22391%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2215%22%20font-weight%3D%22800%22%20fill%3D%22%23ffffff%22%3E%ED%8C%90%EC%A0%95%3A%20%EB%B3%B4%EC%99%84%20%EC%9A%94%EC%B2%AD%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22598%22%20y%3D%22444%22%20text-anchor%3D%22end%22%20font-family%3D%22monospace%22%20font-size%3D%2213%22%20fill%3D%22%23475569%22%3E2026-11-16%20SITE-CAM%204%3A3%3C%2Ftext%3E%0A%20%20%3C%2Fsvg%3E"
      },
      {
        "location": "지하1층 기계실 벽체 관통부",
        "trade": "기계설비·방화구획",
        "status": "정상 확인",
        "note": "배관 관통 슬리브 주변 내화채움재 밀실 시공 및 표시 명판 부착 완료",
        "actionNote": "",
        "dueDate": "",
        "dataUrl": "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22640%22%20height%3D%22480%22%20viewBox%3D%220%200%20640%20480%22%3E%0A%20%20%20%20%3Crect%20width%3D%22640%22%20height%3D%22480%22%20fill%3D%22%23e5e7eb%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2224%22%20y%3D%2224%22%20width%3D%22592%22%20height%3D%22432%22%20fill%3D%22%23f8fafc%22%20stroke%3D%22%2394a3b8%22%20stroke-width%3D%222%22%20rx%3D%228%22%2F%3E%0A%20%20%20%20%3Cline%20x1%3D%2224%22%20y1%3D%22240%22%20x2%3D%22616%22%20y2%3D%22240%22%20stroke%3D%22%23cbd5e1%22%20stroke-dasharray%3D%226%206%22%2F%3E%0A%20%20%20%20%3Cline%20x1%3D%22320%22%20y1%3D%2224%22%20x2%3D%22320%22%20y2%3D%22456%22%20stroke%3D%22%23cbd5e1%22%20stroke-dasharray%3D%226%206%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2288%22%20y%3D%2296%22%20width%3D%22464%22%20height%3D%22240%22%20fill%3D%22%23eef2f6%22%20stroke%3D%22%230f766e%22%20stroke-width%3D%223%22%20rx%3D%226%22%2F%3E%0A%20%20%20%20%3Cpath%20d%3D%22M120%20300%20L240%20160%20L350%20265%20L430%20195%20L520%20300%20Z%22%20fill%3D%22%230f766e%22%20opacity%3D%220.18%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2238%22%20y%3D%2238%22%20width%3D%22168%22%20height%3D%2234%22%20rx%3D%225%22%20fill%3D%22%230f172a%22%2F%3E%0A%20%20%20%20%3Ctext%20x%3D%2250%22%20y%3D%2260%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2215%22%20font-weight%3D%22700%22%20fill%3D%22%23ffffff%22%3ECUT-05%20%C2%B7%20%ED%98%84%EC%9E%A5%EA%B2%80%EC%B8%A1%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22215%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2223%22%20font-weight%3D%22800%22%20fill%3D%22%230f172a%22%3E%EB%B0%A9%ED%99%94%EA%B5%AC%ED%9A%8D%20%EB%B0%B0%EA%B4%80%20%EA%B4%80%ED%86%B5%EB%B6%80%20%EB%82%B4%ED%99%94%EC%B1%84%EC%9B%80%20%EA%B2%80%EC%B8%A1%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22252%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2216%22%20fill%3D%22%23334155%22%3E%EC%9C%84%EC%B9%98%3A%20B1%20%EA%B8%B0%EA%B3%84%EC%8B%A4%20%EC%9D%B8%EC%A0%91%EB%B2%BD%3C%2Ftext%3E%0A%20%20%20%20%3Crect%20x%3D%22220%22%20y%3D%22366%22%20width%3D%22200%22%20height%3D%2238%22%20rx%3D%2219%22%20fill%3D%22%230f766e%22%2F%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22391%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2215%22%20font-weight%3D%22800%22%20fill%3D%22%23ffffff%22%3E%ED%8C%90%EC%A0%95%3A%20%EC%A0%95%EC%83%81%20%ED%99%95%EC%9D%B8%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22598%22%20y%3D%22444%22%20text-anchor%3D%22end%22%20font-family%3D%22monospace%22%20font-size%3D%2213%22%20fill%3D%22%23475569%22%3E2026-11-16%20SITE-CAM%204%3A3%3C%2Ftext%3E%0A%20%20%3C%2Fsvg%3E"
      },
      {
        "location": "1층 주출입구 외부 접근로",
        "trade": "외구·미장공사",
        "status": "정상 확인",
        "note": "장애인 경사로 유효폭 1,350mm 및 기울기 1/12 이하(실측 1/14) 적합",
        "actionNote": "",
        "dueDate": "",
        "dataUrl": "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22640%22%20height%3D%22480%22%20viewBox%3D%220%200%20640%20480%22%3E%0A%20%20%20%20%3Crect%20width%3D%22640%22%20height%3D%22480%22%20fill%3D%22%23e5e7eb%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2224%22%20y%3D%2224%22%20width%3D%22592%22%20height%3D%22432%22%20fill%3D%22%23f8fafc%22%20stroke%3D%22%2394a3b8%22%20stroke-width%3D%222%22%20rx%3D%228%22%2F%3E%0A%20%20%20%20%3Cline%20x1%3D%2224%22%20y1%3D%22240%22%20x2%3D%22616%22%20y2%3D%22240%22%20stroke%3D%22%23cbd5e1%22%20stroke-dasharray%3D%226%206%22%2F%3E%0A%20%20%20%20%3Cline%20x1%3D%22320%22%20y1%3D%2224%22%20x2%3D%22320%22%20y2%3D%22456%22%20stroke%3D%22%23cbd5e1%22%20stroke-dasharray%3D%226%206%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2288%22%20y%3D%2296%22%20width%3D%22464%22%20height%3D%22240%22%20fill%3D%22%23eef2f6%22%20stroke%3D%22%230f766e%22%20stroke-width%3D%223%22%20rx%3D%226%22%2F%3E%0A%20%20%20%20%3Cpath%20d%3D%22M120%20300%20L240%20160%20L350%20265%20L430%20195%20L520%20300%20Z%22%20fill%3D%22%230f766e%22%20opacity%3D%220.18%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2238%22%20y%3D%2238%22%20width%3D%22168%22%20height%3D%2234%22%20rx%3D%225%22%20fill%3D%22%230f172a%22%2F%3E%0A%20%20%20%20%3Ctext%20x%3D%2250%22%20y%3D%2260%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2215%22%20font-weight%3D%22700%22%20fill%3D%22%23ffffff%22%3ECUT-06%20%C2%B7%20%ED%98%84%EC%9E%A5%EA%B2%80%EC%B8%A1%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22215%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2223%22%20font-weight%3D%22800%22%20fill%3D%22%230f172a%22%3E1%EC%B8%B5%20%EC%A3%BC%EC%B6%9C%EC%9E%85%EA%B5%AC%20%EA%B2%BD%EC%82%AC%EB%A1%9C%20%EC%9C%A0%ED%9A%A8%ED%8F%AD%C2%B7%EA%B8%B0%EC%9A%B8%EA%B8%B0%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22252%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2216%22%20fill%3D%22%23334155%22%3E%EC%9C%84%EC%B9%98%3A%201F%20%EC%A0%84%EB%A9%B4%20%EC%A3%BC%EC%B6%9C%EC%9E%85%EA%B5%AC%3C%2Ftext%3E%0A%20%20%20%20%3Crect%20x%3D%22220%22%20y%3D%22366%22%20width%3D%22200%22%20height%3D%2238%22%20rx%3D%2219%22%20fill%3D%22%230f766e%22%2F%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22391%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2215%22%20font-weight%3D%22800%22%20fill%3D%22%23ffffff%22%3E%ED%8C%90%EC%A0%95%3A%20%EC%A0%95%EC%83%81%20%ED%99%95%EC%9D%B8%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22598%22%20y%3D%22444%22%20text-anchor%3D%22end%22%20font-family%3D%22monospace%22%20font-size%3D%2213%22%20fill%3D%22%23475569%22%3E2026-11-16%20SITE-CAM%204%3A3%3C%2Ftext%3E%0A%20%20%3C%2Fsvg%3E"
      }
    ]
  },
  "02_창호방수_보완기한누락_검수대기.json": {
    "meta": {
      "projectName": "연희동 근생 신축 2차 현장검측 (기한누락 점검용)",
      "inspectDate": "2026-11-16",
      "inspector": "김서연 건축사보",
      "contractor": "서연건설",
      "layoutMode": 2
    },
    "items": [
      {
        "location": "2층 화장실 방수턱",
        "trade": "습식방수공사",
        "status": "보완 요청",
        "note": "담수 테스트 전 배수 드레인 주변 프라이머 미도포 구간 확인",
        "actionNote": "",
        "dueDate": "",
        "dataUrl": "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22640%22%20height%3D%22480%22%20viewBox%3D%220%200%20640%20480%22%3E%0A%20%20%20%20%3Crect%20width%3D%22640%22%20height%3D%22480%22%20fill%3D%22%23e5e7eb%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2224%22%20y%3D%2224%22%20width%3D%22592%22%20height%3D%22432%22%20fill%3D%22%23f8fafc%22%20stroke%3D%22%2394a3b8%22%20stroke-width%3D%222%22%20rx%3D%228%22%2F%3E%0A%20%20%20%20%3Cline%20x1%3D%2224%22%20y1%3D%22240%22%20x2%3D%22616%22%20y2%3D%22240%22%20stroke%3D%22%23cbd5e1%22%20stroke-dasharray%3D%226%206%22%2F%3E%0A%20%20%20%20%3Cline%20x1%3D%22320%22%20y1%3D%2224%22%20x2%3D%22320%22%20y2%3D%22456%22%20stroke%3D%22%23cbd5e1%22%20stroke-dasharray%3D%226%206%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2288%22%20y%3D%2296%22%20width%3D%22464%22%20height%3D%22240%22%20fill%3D%22%23eef2f6%22%20stroke%3D%22%23dc2626%22%20stroke-width%3D%223%22%20rx%3D%226%22%2F%3E%0A%20%20%20%20%3Cpath%20d%3D%22M120%20300%20L240%20160%20L350%20265%20L430%20195%20L520%20300%20Z%22%20fill%3D%22%23dc2626%22%20opacity%3D%220.18%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2238%22%20y%3D%2238%22%20width%3D%22168%22%20height%3D%2234%22%20rx%3D%225%22%20fill%3D%22%230f172a%22%2F%3E%0A%20%20%20%20%3Ctext%20x%3D%2250%22%20y%3D%2260%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2215%22%20font-weight%3D%22700%22%20fill%3D%22%23ffffff%22%3ECUT-01%20%C2%B7%20%ED%98%84%EC%9E%A5%EA%B2%80%EC%B8%A1%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22215%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2223%22%20font-weight%3D%22800%22%20fill%3D%22%230f172a%22%3E2%EC%B8%B5%20%ED%99%94%EC%9E%A5%EC%8B%A4%20%EB%B0%B0%EC%88%98%20%EB%93%9C%EB%A0%88%EC%9D%B8%20%EB%B0%A9%EC%88%98%20%EB%B0%94%ED%83%95%EB%A9%B4%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22252%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2216%22%20fill%3D%22%23334155%22%3E%EC%9C%84%EC%B9%98%3A%202F%20%EA%B3%B5%EC%9A%A9%ED%99%94%EC%9E%A5%EC%8B%A4%3C%2Ftext%3E%0A%20%20%20%20%3Crect%20x%3D%22220%22%20y%3D%22366%22%20width%3D%22200%22%20height%3D%2238%22%20rx%3D%2219%22%20fill%3D%22%23dc2626%22%2F%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22391%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2215%22%20font-weight%3D%22800%22%20fill%3D%22%23ffffff%22%3E%ED%8C%90%EC%A0%95%3A%20%EB%B3%B4%EC%99%84%20%EC%9A%94%EC%B2%AD%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22598%22%20y%3D%22444%22%20text-anchor%3D%22end%22%20font-family%3D%22monospace%22%20font-size%3D%2213%22%20fill%3D%22%23475569%22%3E2026-11-16%20SITE-CAM%204%3A3%3C%2Ftext%3E%0A%20%20%3C%2Fsvg%3E"
      },
      {
        "location": "1층 로비 천장 몰딩",
        "trade": "수장공사",
        "status": "정상 확인",
        "note": "석고보드 평활도 및 점검구 위치 도면 일치 확인",
        "actionNote": "",
        "dueDate": "",
        "dataUrl": "data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22640%22%20height%3D%22480%22%20viewBox%3D%220%200%20640%20480%22%3E%0A%20%20%20%20%3Crect%20width%3D%22640%22%20height%3D%22480%22%20fill%3D%22%23e5e7eb%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2224%22%20y%3D%2224%22%20width%3D%22592%22%20height%3D%22432%22%20fill%3D%22%23f8fafc%22%20stroke%3D%22%2394a3b8%22%20stroke-width%3D%222%22%20rx%3D%228%22%2F%3E%0A%20%20%20%20%3Cline%20x1%3D%2224%22%20y1%3D%22240%22%20x2%3D%22616%22%20y2%3D%22240%22%20stroke%3D%22%23cbd5e1%22%20stroke-dasharray%3D%226%206%22%2F%3E%0A%20%20%20%20%3Cline%20x1%3D%22320%22%20y1%3D%2224%22%20x2%3D%22320%22%20y2%3D%22456%22%20stroke%3D%22%23cbd5e1%22%20stroke-dasharray%3D%226%206%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2288%22%20y%3D%2296%22%20width%3D%22464%22%20height%3D%22240%22%20fill%3D%22%23eef2f6%22%20stroke%3D%22%230f766e%22%20stroke-width%3D%223%22%20rx%3D%226%22%2F%3E%0A%20%20%20%20%3Cpath%20d%3D%22M120%20300%20L240%20160%20L350%20265%20L430%20195%20L520%20300%20Z%22%20fill%3D%22%230f766e%22%20opacity%3D%220.18%22%2F%3E%0A%20%20%20%20%3Crect%20x%3D%2238%22%20y%3D%2238%22%20width%3D%22168%22%20height%3D%2234%22%20rx%3D%225%22%20fill%3D%22%230f172a%22%2F%3E%0A%20%20%20%20%3Ctext%20x%3D%2250%22%20y%3D%2260%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2215%22%20font-weight%3D%22700%22%20fill%3D%22%23ffffff%22%3ECUT-02%20%C2%B7%20%ED%98%84%EC%9E%A5%EA%B2%80%EC%B8%A1%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22215%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2223%22%20font-weight%3D%22800%22%20fill%3D%22%230f172a%22%3E1%EC%B8%B5%20%EB%A1%9C%EB%B9%84%20%EC%B2%9C%EC%9E%A5%20%EC%84%9D%EA%B3%A0%EB%B3%B4%EB%93%9C%20%EB%B0%8F%20%EC%A0%90%EA%B2%80%EA%B5%AC%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22252%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2216%22%20fill%3D%22%23334155%22%3E%EC%9C%84%EC%B9%98%3A%201F%20%EB%A9%94%EC%9D%B8%20%EB%A1%9C%EB%B9%84%3C%2Ftext%3E%0A%20%20%20%20%3Crect%20x%3D%22220%22%20y%3D%22366%22%20width%3D%22200%22%20height%3D%2238%22%20rx%3D%2219%22%20fill%3D%22%230f766e%22%2F%3E%0A%20%20%20%20%3Ctext%20x%3D%22320%22%20y%3D%22391%22%20text-anchor%3D%22middle%22%20font-family%3D%22Malgun%20Gothic%2Csans-serif%22%20font-size%3D%2215%22%20font-weight%3D%22800%22%20fill%3D%22%23ffffff%22%3E%ED%8C%90%EC%A0%95%3A%20%EC%A0%95%EC%83%81%20%ED%99%95%EC%9D%B8%3C%2Ftext%3E%0A%20%20%20%20%3Ctext%20x%3D%22598%22%20y%3D%22444%22%20text-anchor%3D%22end%22%20font-family%3D%22monospace%22%20font-size%3D%2213%22%20fill%3D%22%23475569%22%3E2026-11-16%20SITE-CAM%204%3A3%3C%2Ftext%3E%0A%20%20%3C%2Fsvg%3E"
      }
    ]
  }
};
let appState = JSON.parse(JSON.stringify(EMBEDDED_PHOTO_SAMPLES['01_성수동_현장검측_6컷_정상.json']));

// FileReader + Canvas 4:3 (960x720) 로컬 리사이즈 함수 (외부 서버 전송 없음)
function resizeImageTo4x3(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = 960;
        canvas.height = 720;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#f8fafc';
        ctx.fillRect(0, 0, 960, 720);
        const targetRatio = 960 / 720;
        const srcRatio = img.width / img.height;
        let sx = 0, sy = 0, sw = img.width, sh = img.height;
        if (srcRatio > targetRatio) { sw = img.height * targetRatio; sx = (img.width - sw) / 2; }
        else { sh = img.width / targetRatio; sy = (img.height - sh) / 2; }
        ctx.drawImage(img, sx, sy, sw, sh, 0, 0, 960, 720);
        resolve(canvas.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = reject;
      img.src = reader.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function renderLeftList() {
  document.getElementById('m-project').value = appState.meta.projectName || '';
  document.getElementById('m-date').value = appState.meta.inspectDate || '';
  document.getElementById('m-inspector').value = appState.meta.inspector || '';
  document.getElementById('m-contractor').value = appState.meta.contractor || '';
  document.getElementById('m-layout').value = String(appState.meta.layoutMode || 2);

  const box = document.getElementById('cut-list');
  box.innerHTML = '';
  appState.items.forEach((it, i) => {
    const div = document.createElement('div');
    div.className = 'cut-card';
    div.innerHTML = `
      <div>
        <img src="${it.dataUrl}" alt="cut-${i+1}">
        <button type="button" data-del="${i}" style="width:100%;margin-top:4px;padding:3px;font-size:11px">컷 삭제</button>
      </div>
      <div class="cut-fields">
        <input data-i="${i}" data-k="location" value="${(it.location||'').replace(/"/g,'&quot;')}" placeholder="위치 (예: 2층 창호)">
        <input data-i="${i}" data-k="trade" value="${(it.trade||'').replace(/"/g,'&quot;')}" placeholder="공종 (예: 방수공사)">
        <select data-i="${i}" data-k="status">
          ${['정상 확인','보완 요청','재검측'].map(s => `<option value="${s}" ${it.status===s?'selected':''}>${s}</option>`).join('')}
        </select>
        <input data-i="${i}" data-k="dueDate" value="${(it.dueDate||'').replace(/"/g,'&quot;')}" placeholder="조치기한 (보완 시 필수)">
        <input data-i="${i}" data-k="note" value="${(it.note||'').replace(/"/g,'&quot;')}" placeholder="검측 내용 메모" style="grid-column:span 2">
        <input data-i="${i}" data-k="actionNote" value="${(it.actionNote||'').replace(/"/g,'&quot;')}" placeholder="보완 지시사항 (보완 요청 시 필수)" style="grid-column:span 2">
      </div>`;
    box.appendChild(div);
  });
}

function renderRightPreview() {
  const validation = validateInspection(appState.meta, appState.items);
  document.getElementById('sheets-preview').innerHTML = buildPhotoSheetsHtml(appState.meta, appState.items, validation).join('');
  return validation;
}

document.addEventListener('input', (e) => {
  const t = e.target;
  if (t.id === 'm-project') appState.meta.projectName = t.value;
  else if (t.id === 'm-date') appState.meta.inspectDate = t.value;
  else if (t.id === 'm-inspector') appState.meta.inspector = t.value;
  else if (t.id === 'm-contractor') appState.meta.contractor = t.value;
  else if (t.id === 'm-layout') appState.meta.layoutMode = Number(t.value);
  else if (t.dataset.k) appState.items[Number(t.dataset.i)][t.dataset.k] = t.value;
  renderRightPreview();
});

document.addEventListener('click', (e) => {
  const del = e.target.closest('[data-del]');
  if (del) {
    appState.items.splice(Number(del.dataset.del), 1);
    renderLeftList();
    renderRightPreview();
  }
});

document.getElementById('apply-sample-btn').addEventListener('click', () => {
  const k = document.getElementById('sample-select').value;
  appState = JSON.parse(JSON.stringify(EMBEDDED_PHOTO_SAMPLES[k]));
  renderLeftList();
  renderRightPreview();
});

document.getElementById('photo-upload').addEventListener('change', async (e) => {
  const files = [...e.target.files];
  for (const file of files) {
    const dataUrl = await resizeImageTo4x3(file);
    appState.items.push({
      location: file.name.replace(/\.[^.]+$/, ''),
      trade: '현장조사',
      status: '정상 확인',
      note: '현장 촬영 사진 자동 규격화(4:3) 반영',
      actionNote: '',
      dueDate: '',
      dataUrl
    });
  }
  renderLeftList();
  renderRightPreview();
  e.target.value = '';
});

document.getElementById('word-btn').addEventListener('click', () => {
  const validation = renderRightPreview();
  const html = buildStandalonePhotoDocument(appState.meta, appState.items, validation, true);
  const blob = new Blob([html], { type: 'application/msword;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = (appState.meta.projectName || '현장사진대지') + '_펀치리스트포함.doc';
  a.click();
});

document.getElementById('print-btn').addEventListener('click', () => {
  const validation = renderRightPreview();
  const html = buildStandalonePhotoDocument(appState.meta, appState.items, validation, false);
  let frame = document.getElementById('print-frame');
  if (frame) frame.remove();
  frame = document.createElement('iframe');
  frame.id = 'print-frame';
  frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
  document.body.appendChild(frame);
  frame.contentDocument.open();
  frame.contentDocument.write(html);
  frame.contentDocument.close();
  setTimeout(() => { frame.contentWindow.focus(); frame.contentWindow.print(); }, 180);
});

renderLeftList();
renderRightPreview();
