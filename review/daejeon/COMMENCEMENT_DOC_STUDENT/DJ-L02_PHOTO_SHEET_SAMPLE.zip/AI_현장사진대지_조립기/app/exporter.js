// 1쪽 보완 요청(Punch-List) 요약표 + 2~N쪽 무절단 사진대지 A4 인쇄 / Word(.doc) 조립기
function esc(v) {
  return String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function buildPhotoSheetsHtml(meta, items, validation) {
  const perPage = Number(meta?.layoutMode) === 4 ? 4 : 2;
  const punches = extractPunchList(items);
  const chunks = chunkPhotos(items, perPage);
  const okCount = items.filter((x) => x.status === '정상 확인').length;

  const banner = !validation.ready
    ? `<div class="doc-warn"><strong>[사람 확인(검수 대기)]</strong><ul>${validation.warnings.map((w) => `<li>${esc(w)}</li>`).join('')}</ul></div>`
    : `<div class="doc-ok"><strong>[자동 조립 완료]</strong> 총 ${items.length}컷(정상 ${okCount}건 · 보완요청 ${punches.length}건)이 1쪽 총괄표 및 ${chunks.length}쪽 사진대지로 페이지 분리 조립되었습니다.</div>`;

  const punchRows = punches.length > 0
    ? punches.map((p) => `<tr>
        <td class="c"><strong>${p.punchId}</strong><br/><small>(CUT-0${p.cutNo})</small></td>
        <td>${esc(p.location)}</td>
        <td class="c">${esc(p.trade)}</td>
        <td class="c"><span class="tag-bad">${esc(p.status)}</span></td>
        <td><strong>지적:</strong> ${esc(p.note)}<br/><strong>보완지시:</strong> ${esc(p.actionNote || '[미기재 - 확인 필요]')}</td>
        <td class="c"><strong>${esc(p.dueDate || '[기한 미정]')}</strong></td>
      </tr>`).join('')
    : `<tr><td colspan="6" class="c">보완 요청 또는 재검측 지적 항목이 없습니다 (전 항목 정상 확인).</td></tr>`;

  const summarySheet = `<section class="doc-sheet" data-sheet="punch-summary">
    <div class="doc-badge">FIELD INSPECTION · SHEET 01 / PUNCH-LIST SUMMARY</div>
    <h1 class="doc-title">현장 조사 · 시공/감리 검측 총괄표 및 보완 체크리스트</h1>
    ${banner}
    <table class="doc-table">
      <tbody>
        <tr><th>현장(용역)명</th><td colspan="3"><strong>${esc(meta.projectName || '미기재')}</strong></td></tr>
        <tr><th>검측 일자</th><td>${esc(meta.inspectDate || '-')}</td><th>검측자(감리자)</th><td>${esc(meta.inspector || '-')}</td></tr>
        <tr><th>시공사 / 협력사</th><td>${esc(meta.contractor || '-')}</td><th>촬영·판정 집계</th><td>총 <strong>${items.length}컷</strong> (정상 ${okCount}건 / 보완·재검측 <strong>${punches.length}건</strong>)</td></tr>
      </tbody>
    </table>
    <h2 class="doc-sub">중점 보완 요청(Punch-List) 자동 추출 목록</h2>
    <table class="doc-table">
      <thead><tr><th style="width:11%">번호</th><th style="width:18%">위치(층·실)</th><th style="width:13%">공종</th><th style="width:11%">판정</th><th>검측 지적 및 보완 지시사항</th><th style="width:13%">조치 기한</th></tr></thead>
      <tbody>${punchRows}</tbody>
    </table>
    <div class="sign-row">검측 확인: ${esc(meta.inspector || '            ')} (서명/인) &nbsp;&nbsp;|&nbsp;&nbsp; 시공 입회자: ${esc(meta.contractor || '            ')} (서명/인)</div>
  </section>`;

  const photoSheets = chunks.map((group, pageIdx) => {
    const gridClass = perPage === 4 ? 'photo-grid-4' : 'photo-grid-2';
    const cardsHtml = group.map((it, innerIdx) => {
      const globalIdx = pageIdx * perPage + innerIdx + 1;
      const isBad = it.status !== '정상 확인';
      return `<div class="photo-unit">
        <div class="photo-frame"><img src="${it.dataUrl}" alt="CUT-${globalIdx}"/></div>
        <table class="doc-table photo-meta">
          <tbody>
            <tr>
              <th style="width:18%">컷 / 위치</th>
              <td><strong>CUT-${String(globalIdx).padStart(2, '0')}</strong> · ${esc(it.location || '[위치 미기재]')}</td>
              <th style="width:14%">판정</th>
              <td style="width:20%" class="c"><span class="${isBad ? 'tag-bad' : 'tag-ok'}">${esc(it.status)}</span></td>
            </tr>
            <tr>
              <th>공종 / 내용</th>
              <td colspan="3">[${esc(it.trade || '일반')}] ${esc(it.note || '-')}</td>
            </tr>
            ${isBad ? `<tr><th>보완 · 기한</th><td colspan="3" style="color:#991b1b"><strong>${esc(it.actionNote || '[보완지시 누락]')}</strong> (기한: ${esc(it.dueDate || '미정')})</td></tr>` : ''}
          </tbody>
        </table>
      </div>`;
    }).join('');

    return `<section class="doc-sheet" data-sheet="photo-page-${pageIdx + 1}">
      <div class="doc-badge">PHOTO SHEET ${pageIdx + 1} / ${chunks.length} · (${perPage}칸 그리드 자동 분할)</div>
      <h2 class="doc-title" style="font-size:14pt">현장 조사 · 시공 검측 사진대지 (${esc(meta.projectName || '')})</h2>
      <div class="${gridClass}">${cardsHtml}</div>
    </section>`;
  });

  return [summarySheet, ...photoSheets];
}

function buildStandalonePhotoDocument(meta, items, validation, forWord = false) {
  const sheets = buildPhotoSheetsHtml(meta, items, validation);
  const wordBreak = '<br clear="all" style="mso-special-character:line-break; page-break-before:always;" />';
  const joined = forWord ? sheets.join('\n' + wordBreak + '\n') : sheets.join('\n');
  const headOpen = forWord
    ? '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40" lang="ko"><head><meta charset="utf-8"><!--[if gte mso 9]><xml><w:WordDocument><w:View>Print</w:View><w:Zoom>100</w:Zoom><w:DoNotOptimizeForBrowser/></w:WordDocument></xml><![endif]-->'
    : '<!doctype html><html lang="ko"><head><meta charset="utf-8">';
  return `${headOpen}<title>${esc(meta.projectName || '현장사진대지')}</title><style>
    @page { size: A4 portrait; margin: 14mm; }
    @page WordSection1 { size: 210mm 297mm; margin: 14mm; }
    body { font-family: "Malgun Gothic", sans-serif; color: #111827; margin: 0; font-size: 9.5pt; line-height: 1.4; }
    div.WordSection1 { page: WordSection1; }
    .doc-sheet { box-sizing: border-box; }
    .doc-sheet + .doc-sheet { page-break-before: always; break-before: page; }
    .doc-badge { font-size: 8.5pt; color: #7c2d12; font-weight: 700; }
    .doc-title { font-size: 15.5pt; margin: 3pt 0 9pt; border-bottom: 2px solid #0f172a; padding-bottom: 5pt; }
    .doc-sub { font-size: 11pt; margin: 12pt 0 5pt; }
    .doc-table { width: 100%; border-collapse: collapse; margin-bottom: 6pt; }
    .doc-table thead { display: table-header-group; }
    .doc-table tr, .photo-unit { page-break-inside: avoid; break-inside: avoid; }
    .doc-table th, .doc-table td { border: 1px solid #475569; padding: 4pt 6pt; font-size: 9pt; vertical-align: middle; }
    .doc-table th { background: #f1f5f9; text-align: center; }
    .c { text-align: center; }
    .tag-bad { color: #b91c1c; font-weight: 800; }
    .tag-ok { color: #0f766e; font-weight: 800; }
    .doc-warn { border: 1.5px solid #dc2626; background: #fef2f2; color: #991b1b; padding: 6pt 8pt; margin-bottom: 8pt; font-size: 8.8pt; }
    .doc-ok { border: 1.5px solid #0f766e; background: #f0fdfa; color: #115e59; padding: 6pt 8pt; margin-bottom: 8pt; font-size: 8.8pt; }
    .photo-grid-2 { display: flex; flex-direction: column; gap: 10pt; }
    .photo-grid-2 .photo-frame img { width: 100%; max-height: 82mm; object-fit: contain; background: #f8fafc; border: 1px solid #94a3b8; display: block; }
    .photo-grid-4 { display: grid; grid-template-columns: 1fr 1fr; gap: 8pt; }
    .photo-grid-4 .photo-frame img { width: 100%; height: 54mm; object-fit: contain; background: #f8fafc; border: 1px solid #94a3b8; display: block; }
    .sign-row { margin-top: 16pt; text-align: right; font-weight: 700; font-size: 9.5pt; page-break-inside: avoid; }
  </style></head><body><div class="WordSection1">${joined}</div></body></html>`;
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { buildPhotoSheetsHtml, buildStandalonePhotoDocument };
}
