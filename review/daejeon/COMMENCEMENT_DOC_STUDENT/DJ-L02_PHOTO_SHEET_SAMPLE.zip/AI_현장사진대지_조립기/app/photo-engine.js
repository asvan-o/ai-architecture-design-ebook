// 현장 조사·감리 검측 사진대지 보완 필터링(Filter) & N칸 청크 페이지 분할(Chunk Pagination) 엔진
function chunkPhotos(items, perPage) {
  const size = Number(perPage) === 4 ? 4 : 2;
  const pages = [];
  for (let i = 0; i < items.length; i += size) {
    pages.push(items.slice(i, i + size));
  }
  return pages;
}

function extractPunchList(items) {
  return (items || [])
    .map((item, idx) => ({ ...item, cutNo: idx + 1 }))
    .filter((item) => item.status === '보완 요청' || item.status === '재검측')
    .map((item, pIdx) => ({
      punchId: 'P-' + String(pIdx + 1).padStart(2, '0'),
      cutNo: item.cutNo,
      location: item.location,
      trade: item.trade,
      status: item.status,
      note: item.note,
      actionNote: item.actionNote,
      dueDate: item.dueDate
    }));
}

function validateInspection(meta, items) {
  const warnings = [];
  if (!String(meta?.projectName || '').trim()) warnings.push('현장명(프로젝트명)이 비어 있습니다.');
  if (!String(meta?.inspectDate || '').trim()) warnings.push('검측 일자가 입력되지 않았습니다.');
  if (!String(meta?.inspector || '').trim()) warnings.push('검측자(감리자/담당자) 성명이 비어 있습니다.');
  if (!Array.isArray(items) || items.length === 0) warnings.push('최소 1장 이상의 현장 사진 항목이 필요합니다.');

  (items || []).forEach((it, idx) => {
    const label = `CUT-${String(idx + 1).padStart(2, '0')}`;
    if (!String(it.location || '').trim()) warnings.push(`${label}: 촬영 위치(층·실)가 비어 있습니다.`);
    if (!String(it.dataUrl || '').trim()) warnings.push(`${label}: 사진 이미지가 첨부되지 않았습니다.`);
    if (it.status === '보완 요청' || it.status === '재검측') {
      if (!String(it.actionNote || '').trim()) warnings.push(`${label} (${it.status}): 보완 지시 내용이 비어 있습니다. 임의로 생략하지 말고 구체적 조치 방법을 적어 주세요.`);
      if (!String(it.dueDate || '').trim()) warnings.push(`${label} (${it.status}): 재검측·조치 완료 기한이 지정되지 않았습니다.`);
    }
  });

  return {
    status: warnings.length === 0 ? '자동 조립 완료' : '사람 확인(검수 대기)',
    ready: warnings.length === 0,
    warnings
  };
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = { chunkPhotos, extractPunchList, validateInspection };
}
