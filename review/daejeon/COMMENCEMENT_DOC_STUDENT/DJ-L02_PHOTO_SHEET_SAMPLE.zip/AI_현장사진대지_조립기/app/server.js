const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const PORT = 4177;
const UI_DIR = path.join(__dirname, 'ui');
const MIME = { '.html':'text/html;charset=utf-8', '.js':'text/javascript;charset=utf-8', '.css':'text/css;charset=utf-8', '.json':'application/json;charset=utf-8' };
http.createServer((req, res) => {
  const urlPath = req.url.split('?')[0];
  let filePath = urlPath === '/' ? path.join(UI_DIR, 'index.html')
    : urlPath === '/photo-engine.js' ? path.join(__dirname, 'photo-engine.js')
    : urlPath === '/exporter.js' ? path.join(__dirname, 'exporter.js')
    : path.join(UI_DIR, path.basename(urlPath));
  if (!fs.existsSync(filePath)) { res.writeHead(404); res.end('Not found'); return; }
  res.writeHead(200, { 'Content-Type': MIME[path.extname(filePath)] || 'application/octet-stream' });
  res.end(fs.readFileSync(filePath));
}).listen(PORT, '127.0.0.1', () => console.log('Field Photo Sheet Builder running at http://127.0.0.1:' + PORT));
