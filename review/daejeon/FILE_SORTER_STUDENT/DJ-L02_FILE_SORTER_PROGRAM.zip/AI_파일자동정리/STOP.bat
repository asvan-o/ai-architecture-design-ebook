@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 실행환경을 찾지 못했습니다.
  if /I not "%~1"=="--noninteractive" pause
  exit /b 1
)
node "%~dp0app\app.js" --stop
set "sorterResult=%errorlevel%"
if /I not "%~1"=="--noninteractive" pause
exit /b %sorterResult%
