@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js LTS가 필요합니다. https://nodejs.org/en/download 에서 설치한 뒤 다시 실행하세요.
  if /I not "%~1"=="--noninteractive" pause
  exit /b 1
)
node "%~dp0app\app.js" --start
set "sorterResult=%errorlevel%"
if /I not "%~1"=="--noninteractive" pause
exit /b %sorterResult%
