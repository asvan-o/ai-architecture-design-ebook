'use strict';
const fs = require('node:fs');
const fsp = fs.promises;
const path = require('node:path');
const {createHash,randomUUID} = require('node:crypto');
const {signature} = require('./safe-root.js');
class ChangedDuringCopy extends Error {}
class FileManager {
  constructor(safe, store, rules) {this.safe=safe;this.store=store;this.rules=rules;safe.ensureDirectory('data/staging');}
  async digest(relative) {
    const stat=this.safe.regular(relative);
    const input=await fsp.open(this.safe.path(relative),'r');
    try {
      if(signature(await input.stat())!==signature(stat))throw new ChangedDuringCopy('읽기 전 파일이 변경되었습니다.');
      const hash=createHash('sha256'),buffer=Buffer.alloc(256*1024);
      let offset=0;
      for(;;){const {bytesRead}=await input.read(buffer,0,buffer.length,offset);if(!bytesRead)break;hash.update(buffer.subarray(0,bytesRead));offset+=bytesRead;}
      if(signature(await input.stat())!==signature(stat)||signature(this.safe.regular(relative))!==signature(stat))throw new ChangedDuringCopy('읽는 중 파일이 변경되었습니다.');
      return hash.digest('hex');
    }finally{await input.close();}
  }
  async snapshot(relative, expectedSignature) {
    const stat=this.safe.regular(relative);
    if(signature(stat)!==expectedSignature)throw new ChangedDuringCopy('아직 복사 중입니다.');
    const stage='data/staging/'+randomUUID()+'.partial';
    const input=await fsp.open(this.safe.path(relative),'r');
    let output;
    try {
      if(signature(await input.stat())!==expectedSignature)throw new ChangedDuringCopy('열기 전 파일이 변경되었습니다.');
      output=await fsp.open(this.safe.path(stage),'wx');
      const hash=createHash('sha256'),buffer=Buffer.alloc(256*1024);let offset=0;
      for(;;){
        const {bytesRead}=await input.read(buffer,0,buffer.length,offset);if(!bytesRead)break;
        hash.update(buffer.subarray(0,bytesRead));
        let written=0;while(written<bytesRead){const result=await output.write(buffer,written,bytesRead-written,offset+written);if(!result.bytesWritten)throw new Error('임시 보관본 쓰기 실패');written+=result.bytesWritten;}
        offset+=bytesRead;
      }
      await output.sync();await output.close();output=null;
      if(offset!==stat.size||signature(await input.stat())!==expectedSignature||signature(this.safe.regular(relative))!==expectedSignature)throw new ChangedDuringCopy('복사 중 변경되어 다시 안정 확인합니다.');
      return {stage,sha256:hash.digest('hex'),bytes:offset};
    }catch(error){if(output)await output.close();if(fs.existsSync(this.safe.path(stage)))await fsp.unlink(this.safe.path(stage));throw error;}
    finally{await input.close();}
  }
  async duplicate(hash, size) {
    // Includes pre-existing top-level files in managed folders, not only registry entries.
    for(const folder of ['00_원본보관',...this.rules.folders.map(item=>item.folder)]){
      for(const entry of await fsp.readdir(this.safe.path(folder),{withFileTypes:true})){
        if(!entry.isFile()||entry.name==='.gitkeep')continue;
        const relative=folder+'/'+entry.name;
        const stat=this.safe.regular(relative);
        if(stat.size===size&&await this.digest(relative)===hash)return relative;
      }
    }
    return null;
  }
  async reserveCopy(source, folder, requestedName) {
    this.safe.name(requestedName);
    this.safe.ensureDirectory(folder);
    const extension=path.extname(requestedName),base=path.basename(requestedName,extension);
    const match=base.match(/^(.*)_v(\d+)$/i),stem=match?match[1]:base;
    let candidate=requestedName;
    for(let attempt=0;attempt<10000;attempt++){
      const relative=folder+'/'+candidate;
      try {
        this.safe.regular(source);
        await fsp.copyFile(this.safe.path(source),this.safe.path(relative),fs.constants.COPYFILE_EXCL);
        const handle=await fsp.open(this.safe.path(relative),'r+');try{await handle.sync();}finally{await handle.close();}
        return relative;
      }catch(error){
        if(error.code!=='EEXIST')throw error;
        const names=await fsp.readdir(this.safe.path(folder));
        let maximum=Math.max(1,match?Number(match[2]):1);
        for(const name of names){
          const ext=path.extname(name),root=path.basename(name,ext),version=root.match(/^(.*)_v(\d+)$/i);
          if(ext.toLowerCase()===extension.toLowerCase()&&version&&version[1].toLowerCase()===stem.toLowerCase())maximum=Math.max(maximum,Number(version[2]));
        }
        candidate=stem+'_v'+String(maximum+1).padStart(2,'0')+extension;
      }
    }
    throw new Error('버전 이름을 예약할 수 없습니다.');
  }
  async process(name, expectedSignature, decision) {
    const source='00_수집함/'+this.safe.name(name);
    let snapshot,originalPath,outputPath;
    const record={id:randomUUID(),name,created:new Date().toISOString(),sourcePath:source,status:'failed',reason:''};
    try {
      snapshot=await this.snapshot(source,expectedSignature);
      record.sha256=snapshot.sha256;record.bytes=snapshot.bytes;
      const duplicateOf=await this.duplicate(snapshot.sha256,snapshot.bytes);
      if(duplicateOf){
        Object.assign(record,{status:'duplicate',reason:'이미 처리된 동일 파일입니다. 수집함 파일은 확인을 위해 그대로 남깁니다.',duplicateOf});
        this.store.record(record);return record;
      }
      originalPath=await this.reserveCopy(snapshot.stage,'00_원본보관',name);
      record.originalPath=originalPath;
      if(await this.digest(originalPath)!==snapshot.sha256)throw new Error('원본보관 SHA-256 불일치');
      outputPath=await this.reserveCopy(originalPath,decision.folder,name);
      record.outputPath=outputPath;
      if(await this.digest(outputPath)!==snapshot.sha256)throw new Error('분류 출력 SHA-256 불일치');
      if(signature(this.safe.regular(source))!==expectedSignature)throw new Error('처리 중 입력 파일이 변경되었습니다. 입력과 보관본을 유지합니다.');
      // Write a durable receipt before removing the work input.
      Object.assign(record,{status:'prepared',folder:decision.folder,reason:decision.reason});
      this.store.record(record);
      try {await fsp.unlink(this.safe.path(source));record.status=decision.mode;this.store.save();this.store.event(record.status,{recordId:record.id,name,outputPath});}
      catch(error){record.status='failed';record.reason=error.message;this.store.save();this.store.event('failed',{recordId:record.id,name,reason:error.message});}
      return record;
    }catch(error){
      if(error instanceof ChangedDuringCopy)throw error;
      record.reason=error.message;
      // A receipt may already exist if persistence failed: update it rather than claiming success.
      if(!this.store.registry.records.some(item=>item.id===record.id))this.store.record(record);
      else {Object.assign(this.store.registry.records.find(item=>item.id===record.id),record,{status:'failed'});this.store.save();this.store.event('failed',{name,reason:error.message});}
      return record;
    }finally{
      // Only app-generated staging files are removed; archived originals are never deleted.
      if(snapshot&&fs.existsSync(this.safe.path(snapshot.stage)))await fsp.unlink(this.safe.path(snapshot.stage));
    }
  }
  async manual(id, folder) {
    if(!this.rules.folders.some(item=>item.folder===folder))throw new Error('허용하지 않는 분류입니다.');
    const record=this.store.registry.records.find(item=>item.id===id);
    if(!record||record.status!=='pending')throw new Error('확인 대기 기록을 찾을 수 없습니다.');
    if(folder==='99_분류확인'){this.store.event('manual-kept',{recordId:id,reason:'사람이 기타 / 확인 대기 유지 선택'});return;}
    const source=record.outputPath;
    if(!source.startsWith('99_분류확인/'))throw new Error('확인 대기 폴더의 파일만 수동 분류합니다.');
    const stat=this.safe.regular(source);
    if(await this.digest(source)!==record.sha256)throw new Error('확인 대기 파일 내용이 변경되었습니다. 원본보관을 확인하세요.');
    let output;
    try {
      output=await this.reserveCopy(source,folder,path.basename(source));
      if(await this.digest(output)!==record.sha256||signature(this.safe.regular(source))!==signature(stat))throw new Error('수동 분류 중 내용이 변경되었습니다.');
      const previous=record.outputPath;
      // Persist the output receipt first. Keep the source on any failure.
      record.manualOutputPath=output;this.store.save();
      await fsp.unlink(this.safe.path(source));
      Object.assign(record,{status:'manual',folder,outputPath:output,previousPath:previous,reason:'사용자가 직접 유형 선택'});
      delete record.manualOutputPath;this.store.save();this.store.event('manual',{recordId:id,folder,outputPath:output});
    }catch(error){this.store.event('manual-failed',{recordId:id,reason:error.message,partialOutput:output||null});throw error;}
  }
}
module.exports={FileManager,ChangedDuringCopy};
