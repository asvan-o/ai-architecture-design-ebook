'use strict';
const fs=require('node:fs');
const path=require('node:path');
const http=require('node:http');
const {randomUUID,randomBytes}=require('node:crypto');
const {SafeRoot}=require('./safe-root.js');
const {DataStore}=require('./data-store.js');
const {FileManager}=require('./file-manager.js');
const {Watcher}=require('./watcher.js');
const {start,stop}=require('./control.js');
const {FolderImporter}=require('./folder-importer.js');
const {spawn}=require('node:child_process');
const OUTPUTS=['01_CAD도면','02_BIM건축모델','03_레퍼런스','04_이미지결과','05_3D모델','06_포인트클라우드','07_문서','08_영상','09_데이터','10_압축파일','11_디자인소스','99_분류확인'];
function readRules(safe){
  safe.regular('app/rules.json');
  const rules=JSON.parse(fs.readFileSync(safe.path('app/rules.json'),'utf8'));
  if(rules.schemaVersion!==1||!Number.isInteger(rules.port)||rules.port<1024||rules.port>65535||!Number.isInteger(rules.pollMs)||rules.pollMs<50||!Number.isInteger(rules.stableMs)||rules.stableMs<300)throw new Error('rules.json 실행 설정이 잘못되었습니다.');
  if(JSON.stringify(rules.folders.map(item=>item.folder))!==JSON.stringify(OUTPUTS))throw new Error('허용 분류 폴더가 변경되었습니다.');
  if(!Array.isArray(rules.direct)||!Array.isArray(rules.ambiguous)||!Array.isArray(rules.keywords))throw new Error('분류 규칙 형식 오류');
  for(const rule of [...rules.direct,...rules.keywords])if(!OUTPUTS.includes(rule.folder))throw new Error('분류 규칙에 허용하지 않는 경로가 있습니다.');
  return rules;
}
async function serve(safe,rules){
  const token=randomBytes(32).toString('hex'),instanceId=randomUUID();
  let store,manager,watcher,importer,ownedLock=false,stopping=false,queue=Promise.resolve();
  const enqueue=action=>{const pending=queue.then(action);queue=pending.catch(()=>{});return pending;};
  const origin='http://127.0.0.1:'+rules.port;
  const server=http.createServer((request,response)=>handle(request,response).catch(error=>{
    if(store)try{store.event('ui-failed',{reason:error.message});}catch{}
    if(!response.headersSent)json(response,400,{error:error.message});
    else response.end();
  }));
  server.requestTimeout=10000;server.headersTimeout=10000;server.keepAliveTimeout=1000;
  function json(response,status,value){
    response.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
    response.end(JSON.stringify(value));
  }
  async function input(request){
    let text='';for await(const chunk of request){text+=chunk;if(Buffer.byteLength(text)>16384)throw new Error('요청이 너무 큽니다.');}
    return JSON.parse(text||'{}');
  }
  function state(){
    const records=store.registry.records;
    const pending=records.filter(record=>record.status==='pending').map(record=>({...record,preview:['.png','.jpg','.jpeg','.webp','.gif'].includes(path.extname(record.outputPath).toLowerCase())&&record.bytes<=20*1024*1024}));
    return {
      status:stopping?'stopping':watcher.running?'watching':'failed',root:safe.root,inbox:safe.path('00_수집함'),token,instanceId,
      automaticCount:records.filter(record=>record.status==='automatic').length,manualCount:records.filter(record=>record.status==='manual').length,
      pendingCount:pending.length,duplicateCount:records.filter(record=>record.status==='duplicate').length,
      failedCount:records.filter(record=>record.status==='failed').length,
      folders:rules.folders.map(item=>({...item,count:fs.readdirSync(safe.path(item.folder),{withFileTypes:true}).filter(entry=>entry.isFile()&&entry.name!=='.gitkeep').length})),
      pending,recent:records.slice(-30).reverse(),errors:store.log.events.filter(event=>/failed|rejected/.test(event.type)).slice(-10).reverse(),
      boundary:{writesRootOnly:true,externalReadPolicy:'explicit-selected-top-level',accessedRelativePaths:[...safe.accesses].sort()},stableMs:rules.stableMs,pollMs:rules.pollMs,
    };
  }
  async function handle(request,response){
    if(!['127.0.0.1:'+rules.port,'localhost:'+rules.port].includes(request.headers.host)){json(response,403,{error:'허용하지 않는 Host입니다.'});return;}
    if(request.headers.origin&&!['http://localhost:'+rules.port,origin].includes(request.headers.origin)){json(response,403,{error:'외부 Origin 요청은 허용하지 않습니다.'});return;}
    const route=new URL(request.url,origin).pathname;
    if(request.method==='GET'&&route==='/api/identity'){json(response,200,{root:safe.root,instanceId,pid:process.pid});return;}
    if(!store){json(response,503,{error:'시작 중입니다.'});return;}
    if(request.method==='GET'&&route==='/api/state'){json(response,200,state());return;}
    if(request.method==='POST'){
      if(request.headers['x-sorter-token']!==token){json(response,403,{error:'이 instance의 제어 권한이 없습니다.'});return;}
      if(stopping){json(response,409,{error:'종료 중입니다.'});return;}
      if(route==='/api/import/pick'){json(response,200,await importer.pickFolder());return;}
      if(route==='/api/import/preview'){
        const body=await input(request);json(response,200,importer.list(body.folder));return;
      }
      if(route==='/api/import/execute'){
        const body=await input(request);
        const result=await enqueue(()=>importer.execute(body.id));
        store.event('import-finished',{checked:result.checked,copied:result.copied,skipped:result.skipped,errors:result.errors});
        json(response,200,result);return;
      }
      if(route==='/api/inbox/open'){
        if(process.platform!=='win32')throw new Error('폴더 열기는 Windows에서 사용할 수 있습니다. 프로그램 폴더의 00_수집함을 직접 여세요.');
        safe.ensureDirectory('00_수집함');
        const child=spawn(path.join(process.env.SystemRoot||'C:\\Windows','explorer.exe'),[safe.path('00_수집함')],{windowsHide:true,stdio:'ignore'});
        await new Promise((resolve,reject)=>{child.once('spawn',resolve);child.once('error',reject);});child.unref();
        json(response,200,{ok:true});return;
      }
      if(route==='/api/manual'){
        const body=await input(request);
        await enqueue(()=>manager.manual(body.id,body.folder));
        json(response,200,{ok:true});return;
      }
      if(route==='/api/stop'){
        stopping=true;watcher.stop();importer.cancel();
        json(response,200,{ok:true,status:'stopping'});
        setTimeout(()=>shutdown().catch(error=>{console.error(error);process.exitCode=1;}),20);return;
      }
    }
    if(request.method==='GET'&&route.startsWith('/api/preview/')){
      const id=route.slice('/api/preview/'.length);
      const record=store.registry.records.find(item=>item.id===id&&item.status==='pending');
      if(!record||record.bytes>20*1024*1024){json(response,404,{error:'미리보기 없음'});return;}
      const mime={'.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.gif':'image/gif'}[path.extname(record.outputPath).toLowerCase()];
      if(!mime){json(response,404,{error:'지원하지 않는 미리보기 형식'});return;}
      safe.regular(record.outputPath);
      response.writeHead(200,{'Content-Type':mime,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
      response.end(fs.readFileSync(safe.path(record.outputPath)));return;
    }
    const assets={'/':['app/ui/index.html','text/html; charset=utf-8'],'/style.css':['app/ui/style.css','text/css; charset=utf-8'],'/ui.js':['app/ui/ui.js','text/javascript; charset=utf-8']};
    if(request.method==='GET'&&assets[route]){
      const [relative,mime]=assets[route];safe.regular(relative);
      response.writeHead(200,{'Content-Type':mime,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'"});
      response.end(fs.readFileSync(safe.path(relative)));return;
    }
    json(response,404,{error:'없는 경로입니다.'});
  }
  async function shutdown(){
    if(watcher)watcher.stop();if(importer)importer.cancel();stopping=true;
    await queue;
    while(watcher?.busy)await new Promise(resolve=>setTimeout(resolve,20));
    if(store)store.event('stopped',{instanceId});
    await new Promise(resolve=>{server.close(resolve);server.closeIdleConnections();});
    if(ownedLock){
      for(const relative of ['data/runtime.json','data/instance.lock'])if(fs.existsSync(safe.path(relative)))fs.unlinkSync(safe.path(relative));
      ownedLock=false;
    }
    console.log('종료 완료: 감시·서버 중단');
  }
  try{
    await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(rules.port,'127.0.0.1',resolve);});
    safe.ensureDirectory('data');
    const lock=fs.openSync(safe.path('data/instance.lock'),'wx');ownedLock=true;
    try{fs.writeFileSync(lock,instanceId);}finally{fs.closeSync(lock);}
    for(const folder of ['00_수집함','00_원본보관',...OUTPUTS])safe.ensureDirectory(folder);
    store=new DataStore(safe);
    for(const record of store.registry.records)if(record.status==='prepared'){record.status='failed';record.reason='이전 실행이 처리 중 종료되었습니다. 보관본과 입력 파일을 확인하세요.';}
    store.save();
    manager=new FileManager(safe,store,rules);watcher=new Watcher(safe,manager,store,rules,enqueue);
    importer=new FolderImporter(safe,manager);
    store.write('data/runtime.json',{schemaVersion:1,root:safe.root,port:rules.port,pid:process.pid,instanceId,token});
    store.event('started',{instanceId,port:rules.port});watcher.start();
    console.log('실행 중: '+origin+'\n수집함: '+safe.path('00_수집함'));
    let signalRequested=false;
    for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{if(signalRequested)return;signalRequested=true;shutdown().catch(error=>{console.error(error.message);process.exitCode=1;});});
  }catch(error){
    if(server.listening)await new Promise(resolve=>server.close(resolve));
    if(ownedLock&&fs.existsSync(safe.path('data/instance.lock')))fs.unlinkSync(safe.path('data/instance.lock'));
    if(error.code==='EADDRINUSE')throw new Error('포트 '+rules.port+'가 이미 사용 중입니다. 기존 프로그램을 확인하세요. 다른 포트로 자동 변경하지 않습니다.');
    throw error;
  }
}
(async()=>{
  const [major,minor,patch]=process.versions.node.split('.').map(Number);
  if(major<22||(major===22&&(minor<23||(minor===23&&patch<2))))throw new Error('Node.js 22.23.2 이상 LTS 실행환경을 설치하세요. 이번 패키지 검증 환경은 22.23.2입니다.');
  const safe=new SafeRoot(path.resolve(__dirname,'..'));
  const mode=process.argv[2];
  if(mode==='--start'){await start(safe,safe.path('app/app.js'));return;}
  if(mode==='--stop'){await stop(safe);return;}
  if(mode&&mode!=='--check-runtime')throw new Error('지원하지 않는 실행 옵션입니다.');
  if(mode==='--check-runtime'){console.log('Node '+process.versions.node);return;}
  await serve(safe,readRules(safe));
})().catch(error=>{console.error(error.message);process.exitCode=1;});
