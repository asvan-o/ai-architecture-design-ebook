'use strict';
const fs=require('node:fs');
const http=require('node:http');
const {spawn}=require('node:child_process');
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function request(runtime, route, method='GET'){
  return new Promise((resolve,reject)=>{
    const req=http.request({hostname:'127.0.0.1',port:runtime.port,path:route,method,headers:{'X-Sorter-Token':runtime.token||'',Connection:'close'},timeout:2000},response=>{
      let body='';response.setEncoding('utf8');response.on('data',chunk=>body+=chunk);
      response.on('end',()=>{try{const value=JSON.parse(body);if(response.statusCode>=400)reject(new Error(value.error||'제어 요청 실패'));else resolve(value);}catch(error){reject(error);}});
    });req.on('error',reject);req.on('timeout',()=>req.destroy(new Error('제어 요청 시간 초과')));req.end();
  });
}
function runtime(safe){
  const file=safe.path('data/runtime.json');
  if(!fs.existsSync(file))return null;
  safe.regular('data/runtime.json');
  const value=JSON.parse(fs.readFileSync(file,'utf8'));
  if(value.root!==safe.root||!Number.isInteger(value.port)||value.port<1024||value.port>65535||typeof value.instanceId!=='string'||typeof value.token!=='string')throw new Error('프로그램 전용 제어 기록이 유효하지 않습니다.');
  return value;
}
async function identify(safe,value){
  const identity=await request(value,'/api/identity');
  if(identity.root!==safe.root||identity.instanceId!==value.instanceId||identity.pid!==value.pid)throw new Error('다른 프로그램 instance입니다. 종료하지 않습니다.');
  return identity;
}
async function start(safe, appFile){
  const existing=runtime(safe);
  if(existing){
    try{await identify(safe,existing);console.log('이미 실행 중입니다: http://127.0.0.1:'+existing.port);return;}
    catch{throw new Error('이전 제어 기록이 남아 있습니다. 실행 여부를 확인한 뒤 data/runtime.json과 data/instance.lock을 점검하세요. 자동 삭제하지 않습니다.');}
  }
  safe.ensureDirectory('data');
  const log=safe.path('data/server-output.log');
  if(fs.existsSync(log))safe.regular('data/server-output.log');
  const fd=fs.openSync(log,'a');
  const child=spawn(process.execPath,[appFile],{cwd:safe.root,detached:true,windowsHide:true,stdio:['ignore',fd,fd]});
  fs.closeSync(fd);let exited=false;child.on('exit',()=>exited=true);child.on('error',()=>exited=true);child.unref();
  for(let attempt=0;attempt<100;attempt++){
    const current=runtime(safe);
    if(current){try{await identify(safe,current);console.log('실행 중: http://127.0.0.1:'+current.port+'\n종료: STOP.bat\n수집함: '+safe.path('00_수집함'));return;}catch{}}
    if(exited){const text=fs.readFileSync(safe.path('data/server-output.log'),'utf8').slice(-2400);throw new Error('실행 실패:\n'+text);}
    await sleep(100);
  }
  throw new Error('실행 상태 확인 시간이 초과되었습니다. data/server-output.log를 확인하세요.');
}
async function stop(safe){
  const value=runtime(safe);
  if(!value){console.log('이미 종료된 상태입니다.');return;}
  await identify(safe,value);
  await request(value,'/api/stop','POST');
  for(let attempt=0;attempt<300;attempt++){
    await sleep(100);
    if(!fs.existsSync(safe.path('data/runtime.json'))){console.log('이 프로그램 instance의 감시·서버가 종료되었습니다.');return;}
  }
  throw new Error('현재 파일 처리가 안전하게 끝나기를 기다리는 중입니다. 잠시 뒤 STOP.bat으로 상태를 확인하세요.');
}
module.exports={start,stop,request};
