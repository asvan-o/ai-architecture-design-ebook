'use strict';
const fs = require('node:fs');
const path = require('node:path');

class SafeRoot {
  constructor(root) {
    if (fs.lstatSync(root).isSymbolicLink()) throw new Error('프로그램 루트에 링크를 사용할 수 없습니다.');
    this.root = fs.realpathSync(root);
    this.accesses = new Set();
  }
  path(relative) {
    if (typeof relative !== 'string' || relative.includes('\0') || path.isAbsolute(relative) || /^[a-z]:/i.test(relative)) throw new Error('프로그램 밖 경로는 사용할 수 없습니다.');
    const absolute = path.resolve(this.root, relative);
    const within = path.relative(this.root, absolute);
    if (within === '..' || within.startsWith('..' + path.sep) || path.isAbsolute(within)) throw new Error('프로그램 밖 경로는 사용할 수 없습니다.');
    let current = this.root;
    for (const part of within.split(path.sep).filter(Boolean)) {
      current = path.join(current, part);
      try {
        const stat = fs.lstatSync(current);
        if (stat.isSymbolicLink()) throw new Error('심볼릭 링크·junction은 처리하지 않습니다: ' + relative);
      } catch (error) {
        if (error.code !== 'ENOENT') throw error;
      }
    }
    this.accesses.add(within.replaceAll('\\', '/'));
    return absolute;
  }
  regular(relative) {
    const absolute = this.path(relative);
    const stat = fs.lstatSync(absolute);
    if (!stat.isFile() || stat.nlink > 1) throw new Error('일반 파일만 처리합니다. 디렉토리·링크·hardlink는 제외합니다: ' + relative);
    return stat;
  }
  ensureDirectory(relative) {
    const absolute = this.path(relative);
    fs.mkdirSync(absolute, {recursive:true});
    if (!fs.lstatSync(absolute).isDirectory()) throw new Error('폴더가 필요합니다: ' + relative);
    this.path(relative);
    return absolute;
  }
  name(name) {
    if (typeof name !== 'string' || !name || name === '.' || name === '..' || /[\\/:*\?"<>|\0]/.test(name)) throw new Error('허용하지 않는 파일명입니다.');
    return name;
  }
}
const signature = stat => [stat.dev, stat.ino, stat.size, stat.mtimeMs, stat.ctimeMs].join(':');
module.exports = {SafeRoot, signature};
