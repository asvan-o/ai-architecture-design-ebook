'use strict';
const path = require('node:path');
function ignored(name) {
  return name === '.gitkeep' || name.startsWith('~$') || ['.tmp','.part','.crdownload'].includes(path.extname(name).toLowerCase());
}
function classify(name, rules) {
  const extension = path.extname(name).toLowerCase();
  const direct = rules.direct.find(rule => rule.extensions.includes(extension));
  if (direct) return {folder:direct.folder, reason:'명확한 확장자 ' + extension, mode:'automatic'};
  if (!rules.ambiguous.includes(extension)) return {folder:'99_분류확인',reason:'미등록 또는 용도가 다양한 확장자 ' + extension,mode:'pending'};
  const stem = path.basename(name, path.extname(name)).toLowerCase();
  const words = stem.split(/[^a-z0-9]+/).filter(Boolean);
  // English tokens must be whole words. Korean keywords use substring matches.
  const candidates = rules.keywords.filter(rule => rule.words.some(word => /^[a-z0-9]+$/i.test(word) ? words.includes(word.toLowerCase()) : stem.includes(word)));
  if (candidates.length === 1) return {folder:candidates[0].folder,reason:'파일명 단서: ' + candidates[0].label,mode:'automatic'};
  return {folder:'99_분류확인',reason:candidates.length ? '서로 다른 분류의 파일명 단서 충돌' : '파일명만으로 용도 확인 불가',mode:'pending'};
}
module.exports = {classify, ignored};
