'use strict';
const fs = require('node:fs');
const {randomUUID} = require('node:crypto');
class DataStore {
  constructor(safe) {
    this.safe = safe;
    safe.ensureDirectory('data');
    this.registry = this.read('data/registry.json', {schemaVersion:1,records:[]});
    this.log = this.read('data/log.json', {schemaVersion:1,events:[]});
    if (this.registry.schemaVersion !== 1 || !Array.isArray(this.registry.records) || this.log.schemaVersion !== 1 || !Array.isArray(this.log.events)) throw new Error('기록 파일 형식이 잘못되었습니다. 원본을 보존하고 확인하세요.');
  }
  read(relative, initial) {
    const file = this.safe.path(relative);
    if (!fs.existsSync(file)) {this.write(relative, initial); return initial;}
    this.safe.regular(relative);
    return JSON.parse(fs.readFileSync(file,'utf8'));
  }
  write(relative, value) {
    const temporary = relative + '.writing-' + randomUUID();
    const fd = fs.openSync(this.safe.path(temporary),'wx');
    try {fs.writeFileSync(fd,JSON.stringify(value,null,2)+'\n');fs.fsyncSync(fd);} finally {fs.closeSync(fd);}
    // Replacement is limited to app-owned JSON. User files never use rename overwrite.
    const target = this.safe.path(relative);
    for (let attempt=0;attempt<9;attempt++) {
      if (fs.existsSync(target)) this.safe.regular(relative);
      try {fs.renameSync(this.safe.path(temporary),target);return;}
      catch(error) {
        // Windows readers/scanners may hold the target briefly. Keep the old JSON
        // and durable temporary file; retry only bounded sharing/permission errors.
        if (!['EPERM','EACCES','EBUSY'].includes(error.code)||attempt===8) throw error;
        Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,50);
      }
    }
  }
  record(record) {
    this.registry.records.push(record);
    this.write('data/registry.json',this.registry);
    this.event(record.status,{recordId:record.id,name:record.name,reason:record.reason});
  }
  event(type, detail) {
    this.log.events.push({time:new Date().toISOString(),type,...detail});
    this.write('data/log.json',this.log);
  }
  save() {this.write('data/registry.json',this.registry);}
}
module.exports = {DataStore};
