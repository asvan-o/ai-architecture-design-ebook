'use strict';
const fs=require('node:fs');
const {signature}=require('./safe-root.js');
const {classify,ignored}=require('./classifier.js');
const {ChangedDuringCopy}=require('./file-manager.js');
class Watcher {
  constructor(safe,manager,store,rules,enqueue){
    this.safe=safe;this.manager=manager;this.store=store;this.rules=rules;this.enqueue=enqueue;
    this.observed=new Map();this.running=false;this.busy=false;
  }
  start(){this.running=true;this.timer=setInterval(()=>this.tick(),this.rules.pollMs);this.tick();}
  async tick(){
    if(!this.running||this.busy)return;
    this.busy=true;
    try{
      const entries=fs.readdirSync(this.safe.path('00_수집함'),{withFileTypes:true});
      const seen=new Set();
      for(const entry of entries){
        const name=entry.name;
        if(ignored(name))continue;
        seen.add(name);
        let sig;
        try{sig=signature(this.safe.regular('00_수집함/'+name));}
        catch(error){
          if(!this.observed.get(name)?.rejected){this.store.event('rejected',{name,reason:error.message});this.observed.set(name,{rejected:true});}
          continue;
        }
        const previous=this.observed.get(name),now=Date.now();
        if(!previous||previous.signature!==sig){this.observed.set(name,{signature:sig,stableSince:now,handled:false});continue;}
        if(previous.handled||now-previous.stableSince<this.rules.stableMs)continue;
        if(!this.running)break;
        previous.handled=true;
        await this.enqueue(async()=>{
          if(!this.running){previous.handled=false;return;}
          try{await this.manager.process(name,sig,classify(name,this.rules));}
          catch(error){
            if(error instanceof ChangedDuringCopy){this.observed.delete(name);this.store.event('waiting',{name,reason:error.message});}
            else{this.store.event('failed',{name,reason:error.message});}
          }
        });
      }
      for(const name of this.observed.keys())if(!seen.has(name))this.observed.delete(name);
    }catch(error){
      this.running=false;clearInterval(this.timer);
      try{this.store.event('watcher-failed',{reason:error.message});}catch{}
      console.error('감시 중단: '+error.message);
    }finally{this.busy=false;}
  }
  stop(){this.running=false;clearInterval(this.timer);}
}
module.exports={Watcher};
