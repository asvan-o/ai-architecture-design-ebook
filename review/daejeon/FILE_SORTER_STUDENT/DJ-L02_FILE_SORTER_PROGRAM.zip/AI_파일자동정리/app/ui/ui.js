'use strict';
const el=id=>document.getElementById(id);
let token='',timer,busy=false,stopped=false,importBusy=false,previewId='';
const selections=new Map();
const statusNames={automatic:'자동분류',pending:'확인 대기',manual:'수동분류',duplicate:'중복 · 수집함 유지',failed:'실패',prepared:'처리 중'};
function node(tag,text,className){const item=document.createElement(tag);if(text!==undefined)item.textContent=text;if(className)item.className=className;return item;}
async function post(route,body){
  const response=await fetch(route,{method:'POST',headers:{'Content-Type':'application/json','X-Sorter-Token':token},body:JSON.stringify(body||{})});
  const result=await response.json();if(!response.ok)throw new Error(result.error);return result;
}
function render(state){
  token=state.token;
  el('status').textContent={watching:'감시 중',stopping:'종료 중',failed:'감시 실패'}[state.status]||state.status;
  el('inbox').textContent='AI_파일자동정리 / 00_수집함';
  for(const [id,key] of [['auto-count','automaticCount'],['manual-count','manualCount'],['pending-count','pendingCount'],['duplicate-count','duplicateCount'],['failed-count','failedCount']])el(id).textContent=String(state[key]);
  const pending=el('pending');pending.replaceChildren();
  if(!state.pending.length)pending.append(node('p','확인 대기 파일이 없습니다.'));
  for(const file of state.pending){
    const card=node('article',undefined,'file-card');card.dataset.recordId=file.id;
    if(file.preview){const image=node('img');image.src='/api/preview/'+file.id;image.alt=file.name+' 미리보기';image.loading='lazy';image.addEventListener('error',()=>image.replaceWith(node('p','이 형식은 미리보기를 표시하지 못했습니다. 파일을 직접 확인하세요.')));card.append(image);}
    else card.append(node('p','미리보기 없음 · 파일을 직접 확인하세요.'));
    card.append(node('h3',file.name),node('p',file.reason));
    const label=node('label','분류 유형'),select=node('select');select.id='category-'+file.id;label.htmlFor=select.id;
    const blank=node('option','유형을 선택하세요');blank.value='';select.append(blank);
    for(const folder of state.folders){const option=node('option',folder.folder==='99_분류확인'?'기타 · 확인 대기 유지':folder.label);option.value=folder.folder;select.append(option);}
    select.value=selections.get(file.id)||'';
    select.addEventListener('change',()=>selections.set(file.id,select.value));
    const button=node('button','선택한 유형으로 이동');button.type='button';button.dataset.manual=file.id;
    button.addEventListener('click',async()=>{
      if(!select.value){el('notice').textContent='먼저 분류 유형을 선택하세요.';select.focus();return;}
      busy=true;button.disabled=true;
      try{await post('/api/manual',{id:file.id,folder:select.value});el('notice').textContent='사람의 선택을 기록했습니다.';}
      catch(error){el('notice').textContent='실패: '+error.message;}
      finally{busy=false;await refresh();}
    });
    card.append(label,select,button);pending.append(card);
  }
  el('recent').replaceChildren(...state.recent.map(file=>{
    const row=node('tr');row.append(node('td',file.name),node('td',statusNames[file.status]||file.status),node('td',(file.outputPath||file.duplicateOf||'')+' · '+file.reason));return row;
  }));
  el('folders').replaceChildren(...state.folders.map(folder=>node('li',folder.folder+' · '+folder.count+'개')));
  el('errors').replaceChildren(...state.errors.map(error=>node('li',(error.name||'')+' '+error.reason)));
  if(!state.errors.length)el('errors').append(node('li','오류·제외 기록이 없습니다.'));
}
async function refresh(){
  if(stopped||busy)return;
  // Preserve the user's selection while editing a card; explicit refresh is still available.
  if(document.activeElement?.closest('#pending'))return;
  try{const response=await fetch('/api/state',{cache:'no-store'});const state=await response.json();if(!response.ok)throw new Error(state.error);render(state);}
  catch(error){el('status').textContent='연결 실패';el('notice').textContent='프로그램에 연결할 수 없습니다. START.bat 실행 상태와 표시된 주소를 확인한 뒤 새로고침하세요.';}
}
function setImportBusy(value){importBusy=value;for(const id of ['pick-folder','preview-import','import-folder'])el(id).disabled=value;el('execute-import').disabled=value||!previewId;}
function bytesLabel(bytes){return bytes>=1024*1024?(bytes/(1024*1024)).toFixed(1)+' MB':bytes>=1024?(bytes/1024).toFixed(1)+' KB':bytes+' B';}
async function previewImport(){
  if(importBusy||stopped)return;setImportBusy(true);previewId='';el('import-notice').textContent='최상위 파일 목록을 확인 중입니다…';el('import-result').hidden=true;
  try{
    const result=await post('/api/import/preview',{folder:el('import-folder').value});previewId=result.id;
    el('import-preview').hidden=false;el('selected-folder').textContent=result.folder;
    el('import-counts').textContent=result.checked+'개 파일 · 전체 '+bytesLabel(result.bytes)+' · 복사 대상 '+result.candidates+'개 · 건너뜀 '+result.skipped+'개 · 오류 '+result.errors+'개 · 하위 폴더 제외 '+result.foldersExcluded+'개';
    el('import-files').replaceChildren(...result.files.map(file=>node('li',file.name+' · '+bytesLabel(file.bytes)+' · '+(file.status==='candidate'?'복사 대상':file.status==='skip'?'건너뜀: '+file.reason:'오류: '+file.reason))));
    el('import-notice').textContent=result.checked?'파일 목록을 확인한 뒤 파일 가져오기를 누르세요.':'가져올 최상위 파일이 없습니다. 하위 폴더의 파일은 가져오지 않습니다.';
    if(!result.checked)previewId='';
  }catch(error){el('import-preview').hidden=true;el('import-notice').textContent='목록 확인 실패: '+error.message;}
  finally{setImportBusy(false);}
}
el('import-folder').addEventListener('input',()=>{previewId='';el('import-preview').hidden=true;el('execute-import').disabled=true;el('import-notice').textContent='경로를 바꿨습니다. 목록을 다시 확인하세요.';});
el('import-folder').addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();previewImport();}});
el('preview-import').addEventListener('click',previewImport);
el('pick-folder').addEventListener('click',async()=>{
  if(importBusy||stopped)return;setImportBusy(true);previewId='';el('import-preview').hidden=true;el('import-notice').textContent='Windows 폴더 선택창에서 원본 폴더를 선택하세요. 창이 뒤에 있으면 작업 표시줄을 확인하세요.';
  try{const result=await post('/api/import/pick');if(result.cancelled){el('import-notice').textContent='폴더 선택을 취소했습니다. 원본 파일은 바뀌지 않았습니다.';return;}el('import-folder').value=result.folder;}
  catch(error){el('import-notice').textContent=error.message;return;}
  finally{setImportBusy(false);}
  await previewImport();
});
el('execute-import').addEventListener('click',async()=>{
  if(importBusy||stopped||!previewId)return;setImportBusy(true);el('import-notice').textContent='파일을 수집함으로 복사하고 있습니다. 원본은 그대로 유지합니다.';
  try{const result=await post('/api/import/execute',{id:previewId});previewId='';el('import-result').hidden=false;el('import-result-counts').textContent=result.checked+'개 확인 · '+result.copied+'개 복사 · '+result.skipped+'개 건너뜀 · '+result.errors+'개 오류';el('import-result-errors').replaceChildren(...result.files.filter(file=>file.status!=='copied').map(file=>node('li',file.name+' · '+file.reason)));el('import-notice').textContent=result.errors?'가져오기를 마쳤습니다. 아래 오류 파일을 확인하세요. 다른 파일의 분류는 계속 진행됩니다.':'파일 가져오기 완료. 복사된 파일은 기존 감시·분류 흐름으로 처리됩니다.';await refresh();}
  catch(error){el('import-notice').textContent='가져오기 실패: '+error.message;}
  finally{setImportBusy(false);}
});
el('open-inbox').addEventListener('click',async()=>{try{await post('/api/inbox/open');el('notice').textContent='수집함 폴더를 열었습니다. 정리할 파일을 직접 넣을 수 있습니다.';}catch(error){el('notice').textContent=error.message;}});
el('refresh').addEventListener('click',refresh);
el('stop').addEventListener('click',async()=>{
  busy=true;el('stop').disabled=true;
  try{await post('/api/stop');stopped=true;clearInterval(timer);el('status').textContent='종료 요청됨';el('notice').textContent='새 파일 감시는 중단했습니다. 현재 처리 중인 파일이 끝나면 서버가 종료됩니다.';}
  catch(error){busy=false;el('stop').disabled=false;el('notice').textContent='종료 실패: '+error.message;}
});
refresh();timer=setInterval(refresh,2000);
