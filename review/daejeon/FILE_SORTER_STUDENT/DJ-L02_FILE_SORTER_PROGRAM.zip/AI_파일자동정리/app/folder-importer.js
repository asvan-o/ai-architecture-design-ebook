'use strict';
// External inputs are read-only, explicitly selected and limited to top-level files.
const fs=require('node:fs');
const fsp=fs.promises;
const path=require('node:path');
const {randomUUID}=require('node:crypto');
const {spawn}=require('node:child_process');
const {ignored}=require('./classifier.js');
const {signature}=require('./safe-root.js');
const samePath=(a,b)=>path.resolve(a).toLowerCase()===path.resolve(b).toLowerCase();
const inside=(parent,child)=>{const relative=path.relative(parent,child);return relative===''||(!path.isAbsolute(relative)&&relative!=='..'&&!relative.startsWith('..'+path.sep));};
function reason(error){return {EACCES:'파일을 읽을 권한이 없습니다.',EPERM:'다른 프로그램이 파일을 사용 중이거나 읽을 수 없습니다.',EBUSY:'다른 프로그램이 파일을 사용 중입니다.',ENOENT:'파일이 없어졌습니다.'}[error.code]||error.message;}
class FolderImporter {
  constructor(safe,manager){this.safe=safe;this.manager=manager;this.preview=null;this.cancelled=false;this.picker=null;}
  selectedRoot(value){
    if(typeof value!=='string'||!value.trim()||value.includes('\0'))throw new Error('가져올 폴더의 전체 경로를 입력하세요.');
    const entered=value.trim().replace(/^"(.*)"$/,'$1'),folder=path.resolve(entered);
    if(!path.isAbsolute(entered)||/^\\\\/.test(folder))throw new Error('이 PC의 전체 폴더 경로를 사용하세요. 네트워크 공유 경로는 지원하지 않습니다.');
    if(samePath(folder,path.parse(folder).root)||[process.env.USERPROFILE,process.env.APPDATA,process.env.LOCALAPPDATA].filter(Boolean).some(p=>samePath(folder,p)))throw new Error('드라이브·사용자 홈 전체 대신 자료가 들어 있는 작은 폴더를 선택하세요.');
    if(inside(this.safe.root,folder)||inside(folder,this.safe.root))throw new Error('프로그램 폴더와 그 상위 폴더는 가져오기 원본으로 사용할 수 없습니다.');
    const stat=fs.lstatSync(folder);
    if(!stat.isDirectory()||stat.isSymbolicLink())throw new Error('링크가 아닌 일반 폴더를 선택하세요.');
    const real=fs.realpathSync(folder);if(!samePath(real,folder))throw new Error('링크·junction을 경유하는 폴더는 가져오지 않습니다.');
    return {folder:real,identity:[stat.dev,stat.ino].join(':')};
  }
  checkRoot(selected){const current=this.selectedRoot(selected.folder);if(current.identity!==selected.identity)throw new Error('선택한 폴더가 변경되었습니다. 목록을 다시 확인하세요.');}
  file(selected,name){
    this.checkRoot(selected);this.safe.name(name);
    const absolute=path.join(selected.folder,name),stat=fs.lstatSync(absolute);
    if(!stat.isFile()||stat.isSymbolicLink()||stat.nlink>1)throw new Error('링크·hardlink·일반 파일이 아닌 항목은 가져오지 않습니다.');
    if(!samePath(fs.realpathSync(absolute),absolute))throw new Error('원본 파일의 경로가 변경되었습니다.');
    return {absolute,stat};
  }
  list(folder){
    const selected=this.selectedRoot(folder),files=[];let foldersExcluded=0;
    for(const entry of fs.readdirSync(selected.folder,{withFileTypes:true})){
      if(entry.isDirectory()&&!entry.isSymbolicLink()){foldersExcluded++;continue;}
      const row={name:entry.name,bytes:0,status:'candidate',reason:''};
      try{
        if(ignored(entry.name)){const stat=fs.lstatSync(path.join(selected.folder,entry.name));row.bytes=stat.isFile()&&!stat.isSymbolicLink()?stat.size:0;row.status='skip';row.reason='임시파일·처리 제외 이름';}
        else{const current=this.file(selected,entry.name);row.bytes=current.stat.size;row.signature=signature(current.stat);fs.accessSync(current.absolute,fs.constants.R_OK);}
      }catch(error){row.status=entry.isSymbolicLink()?'skip':'error';row.reason=reason(error);}
      files.push(row);
    }
    files.sort((a,b)=>a.name.localeCompare(b.name,'ko'));
    this.preview={...selected,id:randomUUID(),files,foldersExcluded,consumed:false};this.cancelled=false;
    return {id:this.preview.id,folder:selected.folder,checked:files.length,bytes:files.reduce((s,r)=>s+r.bytes,0),candidates:files.filter(r=>r.status==='candidate').length,skipped:files.filter(r=>r.status==='skip').length,errors:files.filter(r=>r.status==='error').length,foldersExcluded,files:files.map(({signature:_signature,...row})=>row)};
  }
  async copy(selected,row){
    const before=this.file(selected,row.name);if(signature(before.stat)!==row.signature)throw new Error('목록 확인 뒤 원본이 변경되었습니다. 다시 확인하세요.');
    const stage='data/staging/import-'+randomUUID()+'.partial';let input,output;
    try{
      input=await fsp.open(before.absolute,fs.constants.O_RDONLY|(fs.constants.O_NOFOLLOW||0));
      if(signature(await input.stat())!==row.signature)throw new Error('읽기 전 원본이 변경되었습니다.');
      output=await fsp.open(this.safe.path(stage),'wx');
      const buffer=Buffer.alloc(256*1024);let offset=0;
      for(;;){
        if(this.cancelled)throw new Error('종료 요청으로 가져오기를 중단했습니다.');
        const {bytesRead}=await input.read(buffer,0,buffer.length,offset);if(!bytesRead)break;
        let written=0;while(written<bytesRead){const result=await output.write(buffer,written,bytesRead-written,offset+written);if(!result.bytesWritten)throw new Error('수집함 복사 준비에 실패했습니다.');written+=result.bytesWritten;}
        offset+=bytesRead;
      }
      await output.sync();await output.close();output=null;
      if(offset!==before.stat.size||signature(await input.stat())!==row.signature||signature(this.file(selected,row.name).stat)!==row.signature)throw new Error('복사 중 원본이 변경되었습니다. 목록을 다시 확인하세요.');
      // Existing name/version reservation, on the same queue as the unchanged watcher.
      return await this.manager.reserveCopy(stage,'00_수집함',row.name);
    }finally{
      if(output)await output.close();if(input)await input.close();
      if(fs.existsSync(this.safe.path(stage)))await fsp.unlink(this.safe.path(stage));
    }
  }
  async execute(id){
    const selected=this.preview;
    if(!selected||selected.id!==id||selected.consumed)throw new Error('선택한 폴더의 목록을 먼저 확인하세요. 가져온 뒤에는 목록을 다시 확인합니다.');
    this.checkRoot(selected);selected.consumed=true;
    const result={checked:selected.files.length,copied:0,skipped:0,errors:0,foldersExcluded:selected.foldersExcluded,files:[]};
    for(const row of selected.files){
      if(row.status==='skip'||this.cancelled){result.skipped++;result.files.push({name:row.name,status:'skipped',reason:this.cancelled?'종료 요청으로 건너뜀':row.reason});continue;}
      try{
        if(row.status==='error')throw new Error(row.reason);
        const inboxPath=await this.copy(selected,row);result.copied++;result.files.push({name:row.name,status:'copied',inboxPath});
      }catch(error){result.errors++;result.files.push({name:row.name,status:'error',reason:reason(error)});}
    }
    return result;
  }
  async pickFolder(){
    if(process.platform!=='win32')throw new Error('Windows 폴더 선택창을 사용할 수 없습니다. 전체 경로를 입력하고 목록을 확인하세요.');
    if(this.picker)throw new Error('이미 열려 있는 폴더 선택창을 확인하세요.');
    this.safe.regular('app/folder-picker.ps1');
    return new Promise((resolve,reject)=>{
      const child=spawn(path.join(process.env.SystemRoot||'C:\\Windows','System32/WindowsPowerShell/v1.0/powershell.exe'),['-NoProfile','-STA','-ExecutionPolicy','Bypass','-File',this.safe.path('app/folder-picker.ps1')],{windowsHide:true,stdio:['ignore','pipe','pipe']});
      this.picker=child;let stdout='',stderr='';const timer=setTimeout(()=>child.kill(),180000);
      child.stdout.on('data',b=>stdout+=b);child.stderr.on('data',b=>stderr+=b);
      child.once('error',error=>{clearTimeout(timer);this.picker=null;reject(error);});
      child.once('exit',code=>{clearTimeout(timer);this.picker=null;try{if(code!==0)throw new Error('폴더 선택창을 열지 못했습니다. 전체 경로를 입력하고 목록을 확인하세요. '+stderr.trim());resolve(JSON.parse(stdout.trim()));}catch(error){reject(error);}});
    });
  }
  cancel(){this.cancelled=true;if(this.picker)this.picker.kill();}
}
module.exports={FolderImporter};
