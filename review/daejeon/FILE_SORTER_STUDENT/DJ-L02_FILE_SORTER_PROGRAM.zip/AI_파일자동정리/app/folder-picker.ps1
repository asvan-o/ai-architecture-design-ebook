param([ValidateSet('Pick','Check')][string]$Mode='Pick')
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
Add-Type -AssemblyName System.Windows.Forms
[Windows.Forms.Application]::EnableVisualStyles()
if($Mode -eq 'Check') { $check=[Windows.Forms.FolderBrowserDialog]::new(); $check.Dispose(); @{supported=$true;type='Windows.Forms.FolderBrowserDialog'} | ConvertTo-Json -Compress; exit 0 }
$dialog=[Windows.Forms.FolderBrowserDialog]::new()
$dialog.Description='Select the source folder. Files are copied; originals are kept.'
$dialog.ShowNewFolderButton=$false
$owner=[Windows.Forms.Form]::new()
$owner.ShowInTaskbar=$false
$owner.TopMost=$true
$owner.Opacity=0
try {
 $owner.Show()
 $answer=$dialog.ShowDialog($owner)
 if($answer -eq [Windows.Forms.DialogResult]::OK) { @{cancelled=$false;folder=$dialog.SelectedPath} | ConvertTo-Json -Compress }
 else { @{cancelled=$true;folder=$null} | ConvertTo-Json -Compress }
} finally { $dialog.Dispose(); $owner.Close(); $owner.Dispose() }
