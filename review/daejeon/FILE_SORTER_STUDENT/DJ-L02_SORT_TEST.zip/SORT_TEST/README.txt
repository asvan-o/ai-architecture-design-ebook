SORT_TEST · 수강생 실습파일

실습파일 11개만 00_수집함에 복사합니다.
README.txt와 manifest.json은 투입하지 않습니다.

office_floorplan.png → 01_CAD도면
  유효 PNG · 기존 교육용 카페 평면도. 파일명은 분류 테스트용이며 오피스 실측도면이 아님.
front_elevation.pdf → 01_CAD도면
  유효 PDF · 기존 교육용 입면도 원본 동일 복사.
material_ref_oak.png → 03_레퍼런스
  유효 PNG · 기존 White Oak 원본 동일 복사.
lighting_ref_3000K.jpg → 03_레퍼런스
  유효 JPEG · 기존 공간 이미지. lighting/3000K는 분류 키워드 테스트명이며 실제 색온도 참고자료가 아님.
render_A_v01.png → 04_이미지결과
  유효 PNG · 기존 강사 결과 예시 원본 동일 복사.
project_brief.docx → 07_문서
  유효 DOCX · 한 페이지 분류 테스트 문서. 교육과정 Design Brief 정답이 아님.
building_model.blend → 05_3D모델
  classification test stub · 실제 Blender 파일이 아니며 Blender에서 열지 않음.
animation_cache.abc → 05_3D모델
  classification test stub · 실제 Alembic cache가 아니며 DCC에서 열지 않음.
walkthrough.mp4 → 08_영상
  유효 MP4 · 기존 JPEG를 사용한 1초 정지영상. 실제 walkthrough가 아님.
image001.png → 99_분류확인
  유효 PNG · 기존 공간 이미지 원본 동일 복사. 파일명에 분류 근거 없음.
scan003.pdf → 99_분류확인
  유효 PDF · 기존 기록지. 실제 스캔 문서가 아니며 파일명에 분류 근거 없음.

.blend/.abc는 classification test stub이며 실제 모델/애니메이션 캐시가 아닙니다.
lighting_ref_3000K.jpg는 파일명 분류 시험용이며 실제 3000K 측정·보증 자료가 아닙니다.
